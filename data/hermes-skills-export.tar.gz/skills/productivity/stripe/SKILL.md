---
name: stripe
description: "Stripe CLI for payments, subscriptions, customers, invoices."
version: 1.0.0
author: Brett Sjoberg, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [stripe, stripe-cli, payments, subscriptions, digital-products, billing, invoices]
    category: payments
    related_skills: [gumroad, airtable, notion]
---

# Stripe CLI

Interact with Stripe via the official `stripe` CLI (v1.50+). Installed at `~/.local/bin/stripe`. Wraps the full Stripe API for managing digital products, subscriptions, customers, invoices, and webhooks.

## Auth

```bash
stripe login                    # browser-based OAuth (TTY)
stripe login --non-interactive  # JSON output for agents (prints URL + code)
stripe login --complete-device  # poll after browser approval
stripe login --interactive      # paste API key directly (SSH/CI)
stripe whoami                    # check current context
stripe login list               # list authorized accounts
stripe switch context           # switch active account/sandbox
```

Credentials stored in `~/.config/stripe/credentials.json` (unencrypted when keyring unavailable). Config at `~/.config/stripe/config.toml`.

## Routing

| Task | CLI command |
|---|---|
| List products | `stripe products list` |
| Create product | `stripe products create --name "My Product" --description "..."` |
| Update product | `stripe products update <id> --name "New Name"` |
| Delete product | `stripe products delete <id>` |
| Create price | `stripe prices create --product <id> --unit-amount 2900 --currency usd` |
| List prices | `stripe prices list --product <id>` |
| Create customer | `stripe customers create --email user@example.com --name "Name"` |
| List customers | `stripe customers list` |
| Search customers | `stripe customers search --query "email:user@example.com"` |
| Create subscription | `stripe subscriptions create --customer <id> --items[][price]=<price_id>` |
| Cancel subscription | `stripe subscriptions cancel <id>` |
| List subscriptions | `stripe subscriptions list --status active` |
| Create checkout session | `stripe checkout sessions create --line-items[][price]=<id> --line-items[][quantity]=1 --mode payment --success_url https://...` |
| Create invoice | `stripe invoices create --customer <id>` |
| Finalize invoice | `stripe invoices finalize <id>` |
| Pay invoice | `stripe invoices pay <id>` |
| List invoices | `stripe invoices list --customer <id>` |
| Create payment intent | `stripe payment_intents create --amount 2900 --currency usd --customer <id>` |
| Capture payment intent | `stripe payment_intents capture <id>` |
| List charges | `stripe charges list --customer <id>` |
| Create refund | `stripe refunds create --charge <id>` |
| Balance | `stripe balance retrieve` |
| List payouts | `stripe payouts list` |
| Listen webhooks | `stripe listen --forward-to localhost:3000/webhooks` |
| Trigger test webhook | `stripe trigger payment_intent.succeeded` |
| Create webhook endpoint | `stripe webhook_endpoints create --url https://... --enabled-events charge.succeeded` |
| List webhooks | `stripe webhook_endpoints list` |

## Core Discipline

- **Auth first:** `stripe whoami` before any write operation.
- **Sandbox by default:** CLI uses sandbox context unless `--live` flag is passed. Always verify context before writes.
- **Idempotency:** Use `--idempotency <key>` on create operations to prevent duplicates.
- **Dry run:** Use `--dry-run` to preview requests before sending.
- **JSON output:** Pipe through `jq` for parsing; use `--format JSON` where supported.
- **Amounts in cents:** `unit-amount`, `amount` are in minor units (cents). $29.00 = 2900.
- **Prices vs Plans:** Stripe CLI uses `prices` (not legacy `plans`) for all new products. Create product first, then price.
- **Subscriptions require prices:** Create a product → create a recurring price → subscribe customer to price.
- **Checkout mode:** `payment` (one-time), `subscription` (recurring), `setup` (save card).
- **Webhook signing:** Use `stripe listen --print-secret` to get the signing secret for verification.
- **Rate limits:** 100 read/100 write requests/sec on HTTP API. CLI handles retries.
- **Test clocks:** Use `stripe test_helpers test_clock` to simulate time-based subscription events.

## Product + Price Pattern (Digital Products)

```bash
# 1. Create the product
stripe products create \
  --name "100 AI Prompts for Real Estate Agents" \
  --description "A curated collection of AI prompts..." \
  --active

# 2. Create a one-time price
stripe prices create \
  --product prod_XXX \
  --unit-amount 2900 \
  --currency usd

# 3. Create a recurring price (subscription)
stripe prices create \
  --product prod_XXX \
  --unit-amount 900 \
  --currency usd \
  --recurring.interval month

# 4. Create checkout session (one-time)
stripe checkout sessions create \
  --line-items[][price]=price_XXX \
  --line-items[][quantity]=1 \
  --mode payment \
  --success_url "https://yoursite.com/success" \
  --cancel_url "https://yoursite.com/cancel"

# 5. Create subscription checkout
stripe checkout sessions create \
  --line-items[][price]=price_XXX \
  --mode subscription \
  --success_url "https://yoursite.com/welcome" \
  --cancel_url "https://yoursite.com/cancel"
```

## Customer + Subscription Pattern

```bash
# Create customer
stripe customers create \
  --email "buyer@example.com" \
  --name "Jane Buyer"

# Subscribe to a price
stripe subscriptions create \
  --customer cus_XXX \
  --items[][price]=price_YYY

# Check active subscriptions
stripe subscriptions list --customer cus_XXX --status active

# Cancel (immediately or at period end)
stripe subscriptions cancel sub_XXX
stripe subscriptions update sub_XXX --cancel-at-period-end
```

## Invoice Pattern

```bash
# Create invoice item first
stripe invoiceitems create \
  --customer cus_XXX \
  --price price_YYY

# Then create + finalize + send invoice
stripe invoices create --customer cus_XXX
stripe invoices finalize inv_XXX
stripe invoices send inv_XXX

# Or pay programmatically
stripe invoices pay inv_XXX
```

## Webhook Testing

```bash
# Get signing secret
stripe listen --print-secret

# Forward to local server
stripe listen --forward-to localhost:3000/webhooks \
  --events payment_intent.succeeded,customer.subscription.created

# Trigger test events
stripe trigger payment_intent.succeeded
stripe trigger customer.subscription.created
stripe trigger invoice.paid
```

## Verification

- Read endpoints return JSON with `id`, `object`, and resource fields.
- Write operations echo the created/updated resource.
- Products: check `"active": true` and `id` starting with `prod_`.
- Prices: check `"unit_amount"` and `"type"` (one_time or recurring).
- Subscriptions: check `"status": "active"` and `current_period_end`.
- Checkout: returns `url` for redirecting the customer.
- Invoices: `"status": "paid"` after successful payment.
- Webhook triggers: events appear in `stripe listen` output or at forward URL.

## Pitfalls

- **Sandbox vs Live:** CLI defaults to sandbox. Use `--live` flag for real charges. Always check `stripe whoami` shows the right context.
- **Prices replace Plans:** The `plans` command exists for legacy only. Always use `prices` for new products.
- **Product required before Price:** You cannot create a price without a product ID. Create product first.
- **Currency lowercase:** `--currency usd` not `USD`.
- **Amounts in cents:** $29.00 = `--unit-amount 2900`. For zero-decimal currencies (JPY), pass the full amount.
- **Subscription requires default payment method:** Creating a subscription without a saved payment method fails. Use Checkout or attach a payment method first.
- **Webhook endpoint URL must be HTTPS** in production. `stripe listen` bypasses this for local dev.
- **Idempotency keys expire after 24 hours.** Use unique keys per logical operation.
- **Test clocks advance subscription time.** Use `stripe test_helpers test_clock create --frozen_time <unix>` to simulate renewals.
- **CLI credentials unencrypted:** When system keyring is unavailable, credentials are stored in plaintext at `~/.config/stripe/credentials.json`.
- **Rate limits apply per account.** Burst requests may return 429; CLI auto-retries with backoff.
- **Refunds are permanent.** Cannot be undone. Confirm amount and charge ID before executing.
- **Disputes (chargebacks):** Use `stripe disputes retrieve <id>` and `stripe disputes close <id>` to manage.

## Plugins

```bash
stripe plugin list
stripe plugin install <name>
```

Available plugins:
- `apps` — build and manage Stripe Apps
- `directory` — search and provision tools/services (may fail on some CPUs with SIGILL)
- `generate` — scaffold integration projects
- `pay` — send money to businesses via @handle
- `projects` — scaffold and manage Stripe integration projects
- `tools` — search, inspect, execute non-public API operations

## Environment

- `STRIPE_API_KEY` — override the active context with a specific API key
- `STRIPE_CONTEXT` — set a compartment context header
- Config file: `~/.config/stripe/config.toml`
- Credentials: `~/.config/stripe/credentials.json`
- CLI path: `~/.local/bin/stripe`
