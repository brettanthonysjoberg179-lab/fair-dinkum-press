---
name: ebook-publishing
description: "Build, package, and publish ebooks — covers, EPUB/PDF generation, Gumroad store pages, and Google Play Books submission."
version: 1.1.0
author: Brett Sjoberg (brettanthonysjoberg179), Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [ebook, publishing, epub, pdf, cover, gumroad, google-books, books, manuscripts]
---

# Ebook Publishing

Generate programmatic SVG covers, assemble multi-chapter manuscripts, build EPUB/PDF files, and publish to Gumroad and Google Play Books.

## When to Use

- Writing a book or multi-chapter ebook
- Generating themed covers for each chapter
- Building a product sales page with cover previews
- Assembling a single manuscript from chapter files
- Building EPUB or PDF for distribution
- Publishing to Gumroad or Google Play Books

## Cover Generation

Write an HTML file with embedded CSS for a full-cover design, then screenshot via browser OR write SVG directly.

### SVG Template (Full Book Cover)

```xml
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 2560" width="100%">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a0505"/>
      <stop offset="100%" stop-color="#2a0f0a"/>
    </linearGradient>
  </defs>
  <rect width="1600" height="2560" fill="url(#bgGrad)"/>
</svg>
```

### SVG to PNG Conversion

```python
import cairosvg
cairosvg.svg2png(
    url='book/cover.svg',
    write_to='book/cover.png',
    output_width=1600,
    output_height=2560
)
```

### HTML Cover Alternative

For complex designs with Google Fonts, gradients, and effects:
1. Write `cover.html` with `@import url('https://fonts.googleapis.com/...')`
2. Screenshot via browser tool: `new_tab('file:///path/cover.html')`, `cdp('Emulation.setDeviceMetricsOverride', width=1600, height=2560)`, `capture_screenshot()`

## EPUB Generation

Use Python's `ebooklib` library. Install with:
```bash
pip3 install ebooklib pyyaml
```

### Minimal Build Script

```python
from pathlib import Path
from ebooklib import epub

book = epub.EpubBook()
book.set_identifier('unique-book-id')
book.set_title('Title Here')
book.set_language('en')
book.add_author('Author Name')

# Add chapters
chapters = sorted(source_dir.glob('ch*.md'))
for i, cf in enumerate(chapters, 1):
    with open(cf, 'r') as f:
        raw = f.read()
    # Strip frontmatter and convert
    meta, body = parse_frontmatter(raw)
    ch = epub.EpubHtml(file_name=f'chap_{i:02d}.xhtml', title=meta.get('title',''), lang='en')
    ch.content = md_to_html(body)
    book.add_item(ch)

book.toc = chapter_list
book.spine = ['nav'] + chapter_list
book.add_item(epub.EpubNcx())
book.add_item(epub.EpubNav())
epub.write_epub('dist/book.epub', book)
```

### PDF Generation

```python
from weasyprint import HTML
HTML('pdf-full.html').write_pdf('dist/book.pdf')
```

## Publishing to Google Play Books

No public API — must use Partner Center web UI: https://play.google.com/books/publish

### Required
- EPUB 3.x (preferred) or PDF
- Cover image (1600×2560 PNG)
- ISBN-13 (register via Bowker/Amazon, or let Google auto-assign)
- Metadata: title, subtitle, author, description, categories

## Publishing to Gumroad Custom Pages

Use `gumroad user page` commands:

```bash
gumroad user page preview ./page.html    # Preview sanitization
gumroad user page publish ./page.html    # Publish
gumroad user page url                   # Get live URL
```

### Gumroad Strips Tags

- `<meta charset="UTF-8">` — stripped, works by default
- `<meta name="viewport">` — stripped, responsiveness preserved by sandbox
- `<title>` — stripped
- `<link rel="preconnect">` — stripped (not on allowlist)
- Google Fonts `<link rel="stylesheet">` — ALLOWED
- Inline `<style>` — preserved

## Pitfalls

- cairosvg uses defusedxml by default — pass `unsafe=True` to allow SVG `url(#id)` references
- SVG viewBox must be space-separated (`0 0 1200 1800`), NOT `1200x1800`
- f-string SVG generation must `html.escape()` text content to avoid XML parse errors
- Gumroad strips meta/title/viewport from custom HTML — use inline styles
- Keep sales-page.html self-contained (no external CSS/JS) for portability
- Name chapter files consistently: `ch01-topic.md`, `ch02-topic.md`, etc.
- Google Play Books accepts EPUB or PDF — EPUB preferred for reflowable text

## File Layout

```
book/<book-name>/
  manuscript.md              # Combined manuscript (all chapters)
  cover.svg / cover.png      # Programmatic cover
  copyright.md / .html       # Copyright page with dedication
  pdf-full.html              # HTML source for PDF generation
  chapter_covers/            # Per-chapter cover images
    ch01-cover.svg / .png ...
  dist/
    the-book-name.epub       # Generated EPUB
    the-book-name.pdf        # Generated PDF
    the-book-name.cover.png  # Cover for upload
  sales-page.html
```

## Reference Files

- `references/ebook-build-recipes.md` — Python build scripts for EPUB/PDF
- `references/gumroad-store-design.md` — Gumroad page design system
- `references/book-cover-design.md` — Cover dimensions, color themes, SVG patterns
