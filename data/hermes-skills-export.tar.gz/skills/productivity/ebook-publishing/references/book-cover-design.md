# Book Cover Design Patterns

## Standard Cover Dimensions

| Format | Dimensions | Notes |
|--------|-----------|-------|
| EPUB/Google Books | 1600×2560 PNG | 2:3 ratio, min 1000px on longest side |
| Kindle Direct | 2560×1600px | 1.6:1 ratio |
| Print (6×9") | 1800×2700px | 300 DPI, CMYK |
| Social media | 1200×1800px | For previews/promotion |

## Color Themes by Genre

### Business/Technology
- Dark navy (#0a0a1a) with cyan (#00d4ff) and purple (#7b2ff7) accents
- Gradient: `linear-gradient(135deg, #00d4ff, #7b2ff7)`
- JetBrains Mono for stats, Inter for headings

### Cultural History/Art
- Warm dark (#0a0505) with orange (#ff4500) and gold (#ffd700)
- Gradient: `linear-gradient(135deg, #ff4500, #ff8c00, #ffd700)`
- Subtle spray-paint dot patterns in background
- "I AM HERE" graffiti watermark at low opacity

### General Nonfiction
- Deep charcoal (#1a1a2e) with accent color matching topic
- Inter for all text, clean minimal layout

## Cover Layout Template

1. **Top accent line** — 4px gradient bar
2. **Eyebrow** — mono uppercase tagline with accent color
3. **Title** — 160px Inter Black, tight tracking
4. **Subtitle** — 36px light weight, muted color
5. **Stats row** — mono numbers with labels
6. **Feature pills** — rounded accent borders
7. **Author block** — gradient avatar circle + name
8. **Publisher** — small mono label + logo
9. **Bottom accent line** — 3px gradient

## SVG Cover Pattern

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 2560">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a0505"/>
      <stop offset="100%" stop-color="#2a0f0a"/>
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ff4500"/>
      <stop offset="50%" stop-color="#ff8c00"/>
      <stop offset="100%" stop-color="#ffd700"/>
    </linearGradient>
    <filter id="glow">
      <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
      <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <rect width="1600" height="2560" fill="url(#bg)"/>
  <rect x="0" y="0" width="1600" height="4" fill="url(#accent)"/>
  <!-- Content here -->
</svg>
```

## Chapter Cover Pattern

Each chapter gets its own cover:
- Same base gradient as book cover
- Chapter number prominently displayed
- Topic-specific icon/emoji
- Title in Inter Black
- Subtitle describing chapter focus

## Copyright Page Elements

```
Title: Book Name: Subtitle
Copyright: © 2026 Author Name. All rights reserved.
Publisher: Publisher Name
ISBN-13: 979-X-XXXX-XXXX-X
Edition: First Edition
Cover Design: Method + credits
Dedication: Short personal note
Disclaimer: Not affiliated with referenced organizations
```