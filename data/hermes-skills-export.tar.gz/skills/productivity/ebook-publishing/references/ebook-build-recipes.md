# Ebook Build Tools & Conversion Recipes

## Required Python Packages

```bash
pip3 install ebooklib pyyaml cairosvg weasyprint
```

| Package | Purpose | Install Command |
|---------|---------|----------------|
| `ebooklib` | EPUB generation | `pip3 install ebooklib` |
| `pyyaml` | Frontmatter parsing | `pip3 install pyyaml` |
| `cairosvg` | SVG → PNG conversion | `pip3 install cairosvg` |
| `weasyprint` | HTML → PDF conversion | `pip3 install weasyprint` |

## EPUB Build Recipe

```python
from pathlib import Path
from ebooklib import epub

def build_epub(source_dir, output_path, metadata):
    book = epub.EpubBook()
    book.set_identifier(metadata['identifier'])
    book.set_title(metadata['title'])
    book.set_language('en')
    book.add_author(metadata['author'])
    
    chapters = sorted(Path(source_dir).glob('ch*.md'))
    epub_chapters = []
    
    for i, cf in enumerate(chapters, 1):
        raw = cf.read_text(encoding='utf-8')
        meta, body = parse_frontmatter(raw)
        ch = epub.EpubHtml(
            uid=f'chap_{i:02d}',
            file_name=f'chap_{i:02d}.xhtml',
            title=meta.get('title', ''),
            lang='en'
        )
        ch.content = md_to_html(body)
        book.add_item(ch)
        epub_chapters.append(ch)
    
    book.toc = epub_chapters
    book.spine = ['nav'] + epub_chapters
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    epub.write_epub(str(output_path), book)
```

## PDF Build Recipe

Combine all chapters into one HTML, then convert:

```python
from weasyprint import HTML
HTML('pdf-full.html').write_pdf('dist/book.pdf')
```

### PDF HTML Requirements
- Use `@page { size: A4; margin: 2cm; }` for page setup
- `@page :first { @bottom-center { content: none; } }` to hide page number on cover
- `@bottom-center { content: counter(page); }` for running page numbers
- `page-break-before: always;` on chapter headings
- `page-break-inside: avoid;` on code blocks

## SVG to PNG Conversion

```python
import cairosvg
cairosvg.svg2png(
    url='cover.svg',
    write_to='cover.png',
    output_width=1600,
    output_height=2560
)
```

## Markdown Frontmatter

Each chapter should start with YAML frontmatter:

```markdown
---
title: Chapter Title
description: Short description
---

# Chapter content here...
```