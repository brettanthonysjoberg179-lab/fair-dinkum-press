# Gumroad Store Page Design

## Design System

### Color Palette (Dark Theme)
```css
:root {
  --bg: #0a0a1a;
  --bg-secondary: #111128;
  --bg-card: #16163a;
  --text-primary: #f0f0ff;
  --text-secondary: #a0a0c0;
  --accent-cyan: #00d4ff;
  --accent-purple: #7b2ff7;
  --accent-pink: #ff2d95;
  --border: rgba(255,255,255,0.06);
}
```

### Light Theme Override
```css
[data-theme="light"] {
  --bg: #f8f9fc;
  --bg-secondary: #ffffff;
  --bg-card: #ffffff;
  --text-primary: #1a1a2e;
  --text-secondary: #4a4a6a;
}
```

### Typography
- **Headings:** Inter, 800 weight, negative letter-spacing (-1 to -1.5px)
- **Body:** Inter, 400 weight, 1.6 line-height
- **Mono:** JetBrains Mono for code/stats
- **Gradient text:** `background: linear-gradient(135deg, var(--accent-cyan), var(--accent-purple)); -webkit-background-clip: text;`

## Page Sections

1. **Header** — Sticky, blur on scroll, logo + theme toggle
2. **Hero** — Badge, h1 with gradient, subtitle, CTA button
3. **Products** — Responsive grid, cards with hover lift + gradient top-border
4. **About** — Bio + stat cards
5. **Newsletter** — `data-gumroad-follow` form with email input
6. **Footer** — Links + copyright

## Key Features

- Dark/light mode toggle (saved to localStorage)
- Fully responsive (single-column on mobile)
- Atmospheric background with animated gradient orbs
- Sticky header with scroll effect
- Product cards with hover animations
- Newsletter form wired to Gumroad audience

## Gumroad Page Publishing

```bash
gumroad user page preview ./page.html    # Check sanitization
gumroad user page publish ./page.html    # Publish
gumroad user page url                   # Get live URL
```

### What Gets Stripped
- `<meta>`, `<title>`, `<link rel="preconnect">` — removed
- `<link rel="stylesheet">` from Google Fonts — ALLOWED
- Inline `<style>` — preserved

## Newsletter Form

```html
<form class="follow-form" data-gumroad-follow>
  <input type="email" placeholder="your@email.com" required>
  <button type="submit">Subscribe</button>
</form>
<div class="follow-message" data-gumroad-follow-message></div>
```

Gumroad auto-wires this to your email audience after compliance review. Until then, visitors go to your Gumroad subscribe page.