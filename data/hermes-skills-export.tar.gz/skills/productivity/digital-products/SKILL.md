---
name: digital-products
description: "Sell digital products with Gumroad, Stripe, fulfillment."
version: 1.0.0
author: Brett Sjoberg (brettanthonysjoberg179), Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [digital-products, gumroad, stripe, fulfillment, airtable, composio]
    related_skills: [gumroad, stripe, airtable, notion, himalaya]
---

# Digital Products Business

Complete system for selling digital products: create, launch, fulfill, and track. Combines Gumroad, Stripe, Composio, Airtable, Notion, and Obsidian into one workflow.

## When to Use

- Creating a new digital product (guide, template, toolkit, course)
- Publishing products to Gumroad or Stripe
- Setting up auto-fulfillment for sales
- Tracking revenue and customers in Airtable
- Planning launches and marketing
- Building landing pages and product pages

## Prerequisites

- `gumroad` CLI: `~/.local/bin/gumroad`
- `stripe` CLI: `~/.local/bin/stripe`
- `composio` CLI: `~/.local/bin/composio`
- `himalaya` CLI: `~/.local/bin/himalaya`
- Airtable PAT in `AIRTABLE_API_KEY`
- Notion integration token in `NOTION_API_KEY`
- Gumroad payment method connected (for publishing)

## Product Workflow

### 1. Create Product Content

Write product files to `~/digital-products/<product-name>/`:
- Main content as `.md` or `.pdf`
- Bonus materials (templates, JSON, Canva files)
- Landing page HTML (if custom)

### 2. Create on Gumroad

```bash
gumroad products create --name "Product Name" --description "..." --price 29.00 --file ./content.md
gumroad products publish <id>
```

### 3. Set Up Landing Page

Dark-themed HTML at `~/digital-products/<name>/landing.html`:
- Hero with product name + value prop
- Table of contents or feature list
- Pricing cards with `data-gumroad-action="buy"` buttons
- FAQ section
- Author bio

Publish: `gumroad user page publish ./landing.html`

### 4. Configure Auto-Fulfillment

Script at `~/.hermes/scripts/auto_fulfill.py`:
- Detects Gumroad sales via Composio
- Logs to Airtable Sales table
- Appends to Obsidian daily note
- Sends delivery email via Himalaya

Cron: `*/15 * * * *`

### 5. Launch Sequence

30-day plan at `~/digital-products/<name>/launch-plan.md`:
- Pre-launch (days 1-14): assets, list building, warmup
- Launch week (days 15-21): daily emails, social posts
- Post-launch (days 22-30): optimization, scaling

## Airtable Schema

**Sales table:**
- Sale ID, Buyer Email, Product Name, Price, Date, Status, Source, Delivered

**Products table:**
- ID, Name, Price, Format, Gumroad ID, Status, Sales Count

## Obsidian Structure

Daily sales at `~/Documents/Obsidian Vault/Sales/YYYY-MM-DD.md`:

```markdown
# Sales — YYYY-MM-DD
| Sale ID | Buyer | Product | Price | Status | Time |
```

## Stripe CLI Commands

```bash
stripe products create --name "Product" --description "..."
stripe prices create --product <id> --unit-amount 2900 --currency usd
stripe checkout sessions create --line-items[][price]=<id> --mode payment --success_url https://...
```

## Composio Connections

```bash
composio link stripe
composio link github
composio link airtable
composio link gumroad
```

Use `composio execute <TOOL>` for Stripe/Airtable operations.

## Product Catalog

Maintain in `~/digital-products/catalog.json`:

```json
{
  "products": [
    {
      "name": "100 AI Prompts for Real Estate Agents",
      "gumroad_id": "zsiu1wV_4uqZo9Xue3MU2Q==",
      "price": 29,
      "format": "pdf",
      "niche": "real-estate"
    }
  ]
}
```

## Pricing Tiers

| Tier | Price | Format |
|------|-------|--------|
| Impulse | $7-$17 | Cheat sheet, checklist |
| Standard | $29-$47 | Guide, mini-course |
| Premium | $97-$197 | Full course + community |
| High-Touch | $497-$997 | Coaching, certification |

## Pitfalls

- Gumroad strips meta/title/viewport from custom HTML — use inline styles
- Gumroad requires payment method before publishing (Stripe payout)
- Composio Gmail needs browser OAuth — use Himalaya for email instead
- Airtable PAT must be scoped per-base for write access
- Stripe CLI defaults to sandbox — use `--live` for real charges
- Obsidian vault path must exist before script writes

## Verification

- [ ] Product published on Gumroad (not draft)
- [ ] Landing page published via `gumroad user page publish`
- [ ] Auto-fulfill cron running (`cronjob(action='list')`)
- [ ] Airtable base has Sales table
- [ ] Composio connections active for Stripe/Airtable/Gumroad
- [ ] Test purchase flow completed

## Related Commands

```bash
# List sales
gumroad sales list --all --json

# Check fulfillment log
cat ~/.hermes/scripts/auto_fulfill.py | grep -A5 "def main"

# Manual fulfillment run
python3 ~/.hermes/scripts/auto_fulfill.py

# Airtable records
curl -s "https://api.airtable.com/v0/$BASE_ID/Sales" -H "Authorization: Bearer $AIRTABLE_API_KEY"
```
