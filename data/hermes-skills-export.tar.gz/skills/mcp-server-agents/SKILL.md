---
name: mcp-server-agents
description: "Use when building MCP servers or designing MCP agent tools."
tags: [mcp, agent, architecture, tool-design, python, fastmcp]
---

# MCP Server Agents Knowledge

Reference for building and deploying MCP (Model Context Protocol) Server Agents. All knowledge modules are stored in the RAGS memory vector database at `/home/brettanthonysjoberg179/rags_memory_db/rags_memory.db`.

## Retrieval
To query MCP knowledge, use the RAGSMemoryDB class:
```python
from rags_memory_db import RAGSMemoryDB
db = RAGSMemoryDB('/home/brettanthonysjoberg179/rags_memory_db/rags_memory.db')
results = db.retrieve("your MCP question", top_k=3)
db.close()
```

## Five Knowledge Modules

### Module 1: MCP Architecture & Core Concepts
- MCP as USB-C for AI applications
- Three transports: stdio, Streamable HTTP (2026 standard), HTTP+SSE (deprecated)
- Three-layer architecture: Doctrine → Agent → Skills → Memory → MCP
- N+M vs N×M integration math

### Module 2: Tool Design Principles
- Single Responsibility Rule: one tool = one clear responsibility
- LLMs select tools via natural language descriptions
- Domain-aligned operations over generic tools
- Tool count guidelines: 3-5 minimum, 10-20 sweet spot

### Module 3: Building an MCP Server (Python/FastMCP)
- `pip install fastmcp`
- Decorators: @mcp.tool(), @mcp.resource(), @mcp.prompt()
- Transport config: mcp.run(transport="stdio") or "streamable-http"
- Use environment variables for credentials

### Module 4: Agent Integration & Patterns
- Strict MCP Purity: server stateless, client handles orchestration
- Multi-agent patterns: Orchestrator, Shared Memory, Task Delegation
- Idempotent tools critical for retry safety

### Module 5: Security & Production
- Auth: API keys, OAuth 2.0, client certificates
- TLS required for all remote connections
- Anti-patterns: generic tools, overloaded tools, stateful servers
- MCP05: Command Injection Prevention

## Source: Research gathered September 2026
modelcontextprotocol.io, arxiv papers, shuji-bonji/ai-agent-architecture

## Related Skills
- rags-memory-vector-db: The underlying memory vector database