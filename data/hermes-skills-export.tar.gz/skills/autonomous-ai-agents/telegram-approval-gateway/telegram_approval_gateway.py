#!/usr/bin/env python3
"""
Telegram Approval Gateway for Content Workforce

Sends a generated draft to a Telegram chat for human review.
Waits for the user to approve or reject via Telegram button callbacks.
If rejected, relays feedback back to the writer sub-agent.

Requirements:
  - TELEGRAM_BOT_TOKEN in ~/.hermes/.env
  - TELEGRAM_HOME_CHANNEL in ~/.hermes/.env (target chat ID)

Usage:
  python3 telegram_approval_gateway.py <draft_file> <brief_file>

Returns:
  - "approved" if the reviewer approves
  - "rejected:<feedback>" if the reviewer rejects
  - "timeout" if no response within 24 hours
"""

import os
import sys
import json
import time
import urllib.request
import urllib.error
from pathlib import Path

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
TELEGRAM_HOME_CHANNEL = os.environ.get("TELEGRAM_HOME_CHANNEL")
APPROVAL_TIMEOUT_SECONDS = 86400  # 24 hours
POLL_INTERVAL = 10  # seconds between poll attempts


def telegram_api(method, payload=None):
    """Call the Telegram Bot API."""
    if not TELEGRAM_BOT_TOKEN:
        return {"ok": False, "error": "TELEGRAM_BOT_TOKEN not set"}

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/{method}"

    data = None
    headers = {}

    if payload:
        if "photo" in payload or "document" in payload or "caption" in payload:
            # multipart/form-data for file uploads
            boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
            body_parts = []
            for key, value in payload.items():
                if key in ("photo", "document"):
                    # value is a tuple (filename, file_bytes)
                    filename, file_bytes = value
                    body_parts.append(f"--{boundary}\r\n")
                    body_parts.append(
                        f'Content-Disposition: form-data; name="{key}"; filename="{filename}"\r\n'
                    )
                    body_parts.append("Content-Type: application/octet-stream\r\n\r\n")
                    if isinstance(file_bytes, str):
                        file_bytes = file_bytes.encode("utf-8")
                else:
                    body_parts.append(f"--{boundary}\r\n")
                    body_parts.append(f'Content-Disposition: form-data; name="{key}"\r\n\r\n')
                    body_parts.append(f"{value}\r\n")
            body_parts.append(f"--{boundary}--\r\n")
            data = "".join(body_parts).encode("latin-1") if body_parts else None
            headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
        else:
            # JSON payload
            data = json.dumps(payload).encode("utf-8")
            headers = {"Content-Type": "application/json"}

    req = urllib.request.Request(url, data=data, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.code}: {e.read().decode('utf-8', errors='replace')}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def send_approval_message(draft_content, brief_content):
    """Send the draft to Telegram with inline approval/rejection buttons."""
    # Truncate content if too long (Telegram message limit is 4096 chars)
    preview = draft_content[:3500]
    if len(draft_content) > 3500:
        preview += "\n\n... [truncated — see full draft in workspace]"

    text = (
        f"📝 *Content Draft Ready for Review*\n\n"
        f"---\n{preview}\n---\n\n"
        f"Please review and approve or request changes."
    )

    # Inline keyboard with callback buttons
    reply_markup = json.dumps({
        "inline_keyboard": [
            [
                {"text": "✅ Approve & Publish", "callback_data": "approve"},
                {"text": "❌ Request Changes", "callback_data": "reject"},
            ]
        ]
    })

    result = telegram_api("sendMessage", {
        "chat_id": TELEGRAM_HOME_CHANNEL,
        "text": text,
        "parse_mode": "Markdown",
        "reply_markup": reply_markup,
    })

    if not result.get("ok"):
        return None

    message_id = result["result"]["message_id"]

    # Also send the full draft as a document
    telegram_api("sendDocument", {
        "chat_id": TELEGRAM_HOME_CHANNEL,
        "document": ("draft.md", draft_content.encode("utf-8")),
        "caption": "Full draft attached",
        "reply_to_message_id": message_id,
    })

    return message_id


def wait_for_callback(message_id):
    """Poll for callback queries on the approval message."""
    start_time = time.time()
    last_update_id = 0

    print(f"Waiting for Telegram approval (timeout: {APPROVAL_TIMEOUT_SECONDS}s)...")

    while time.time() - start_time < APPROVAL_TIMEOUT_SECONDS:
        result = telegram_api("getUpdates", {
            "offset": last_update_id + 1,
            "timeout": POLL_INTERVAL,
            "limit": 100,
        })

        if not result.get("ok"):
            time.sleep(POLL_INTERVAL)
            continue

        updates = result.get("result", [])
        for update in updates:
            last_update_id = update.get("update_id", 0)

            if "callback_query" in update:
                callback = update["callback_query"]
                if callback.get("message", {}).get("message_id") == message_id:
                    callback_data = callback.get("data", "")
                    user_id = callback.get("from", {}).get("id", "unknown")

                    # Acknowledge the callback
                    telegram_api("answerCallbackQuery", {
                        "callback_query_id": callback.get("id"),
                        "text": "✅ Received" if callback_data == "approve" else "🔄 Feedback noted",
                    })

                    if callback_data == "approve":
                        # Send confirmation
                        telegram_api("sendMessage", {
                            "chat_id": TELEGRAM_HOME_CHANNEL,
                            "text": "✅ Draft approved! Publishing to WordPress now...",
                        })
                        return "approved"
                    elif callback_data == "reject":
                        # Ask for feedback via a follow-up message
                        telegram_api("sendMessage", {
                            "chat_id": TELEGRAM_HOME_CHANNEL,
                            "text": "❌ Please provide feedback for the revision (reply to this message):",
                        })
                        # Wait for the reply
                        feedback = wait_for_reply(last_update_id, user_id)
                        if feedback:
                            telegram_api("sendMessage", {
                                "chat_id": TELEGRAM_HOME_CHANNEL,
                                "text": f"🔄 Revision requested: {feedback[:200]}",
                            })
                            return f"rejected:{feedback}"
                        else:
                            return "rejected:no feedback provided"

        time.sleep(POLL_INTERVAL)

    return "timeout"


def wait_for_reply(last_update_id, user_id, timeout=3600):
    """Wait for a reply message from the user who clicked reject."""
    start_time = time.time()
    current_offset = last_update_id

    while time.time() - start_time < timeout:
        result = telegram_api("getUpdates", {
            "offset": current_offset + 1,
            "timeout": POLL_INTERVAL,
            "limit": 100,
        })

        if not result.get("ok"):
            time.sleep(POLL_INTERVAL)
            continue

        updates = result.get("result", [])
        for update in updates:
            current_offset = update.get("update_id", 0)

            if "message" in update:
                msg = update["message"]
                sender_id = msg.get("from", {}).get("id")
                reply_to = msg.get("reply_to_message", {})

                # Check if this is a reply to our feedback request from the same user
                if sender_id == user_id and reply_to:
                    return msg.get("text", "no message text")

        time.sleep(POLL_INTERVAL)

    return None


def main():
    if len(sys.argv) < 2:
        print("Usage: python3 telegram_approval_gateway.py <draft_file> [brief_file]")
        print("  draft_file: path to the generated draft markdown")
        print("  brief_file: path to the research brief (optional, for context)")
        sys.exit(1)

    draft_file = sys.argv[1]
    brief_file = sys.argv[2] if len(sys.argv) > 2 else None

    if not TELEGRAM_BOT_TOKEN:
        print("ERROR: TELEGRAM_BOT_TOKEN not set in environment")
        sys.exit(1)

    if not TELEGRAM_HOME_CHANNEL:
        print("ERROR: TELEGRAM_HOME_CHANNEL not set in environment")
        sys.exit(1)

    # Read the draft
    draft_path = Path(draft_file)
    if not draft_path.exists():
        print(f"ERROR: Draft file not found: {draft_file}")
        sys.exit(1)

    draft_content = draft_path.read_text(encoding="utf-8")

    # Read brief if provided
    brief_content = ""
    if brief_file:
        brief_path = Path(brief_file)
        if brief_path.exists():
            brief_content = brief_path.read_text(encoding="utf-8")

    print(f"Sending draft ({len(draft_content)} chars) to Telegram...")

    message_id = send_approval_message(draft_content, brief_content)

    if message_id is None:
        print("ERROR: Failed to send message to Telegram")
        sys.exit(1)

    print(f"Approval message sent (message_id={message_id})")

    # Wait for approval
    result = wait_for_callback(message_id)

    if result == "approved":
        print("RESULT: approved")
        sys.exit(0)
    elif result.startswith("rejected"):
        print(f"RESULT: rejected")
        sys.exit(2)
    else:
        print("RESULT: timeout")
        sys.exit(3)


if __name__ == "__main__":
    main()
