---
name: telegram-approval-gateway
description: "Sends generated content drafts to Telegram for human review with inline approval/rejection buttons; waits for callback and relays feedback."
version: 1.0.0
author: Generated for content workforce
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [telegram, approval, gateway, review, cms, delivery]
    related_skills: [content-pipeline, content-writer, wp-publisher]
---

# Telegram Approval Gateway

Bridges the gap between autonomous content generation and human editorial
control. Sends drafts to a Telegram chat with inline approval/rejection
buttons, waits for the reviewer's decision, and relays feedback back to the
writer sub-agent if changes are needed.

## Prerequisites

- `TELEGRAM_BOT_TOKEN` in `~/.hermes/.env` (from @BotFather)
- `TELEGRAM_HOME_CHANNEL` in `~/.hermes/.env` (target chat/channel ID)
- The `telegram_approval_gateway.py` script in this skill directory

### Getting your Telegram Bot Token

1. Open Telegram and search for `@BotFather`
2. Send `/newbot` and follow the prompts
3. Copy the token (format: `123456789:ABCdefGhIJK...`)
4. Add to `~/.hermes/.env`:
   ```
   TELEGRAM_BOT_TOKEN=123456789:ABCdefGhIJK...
   ```

### Getting your Telegram Channel/Chat ID

- For a **private channel**: Create a channel, add your bot as admin, then
  find the channel's numeric ID (search `@userinfobot` in Telegram, or
  use `chat_id` from a message's JSON).
- For a **group**: Add your bot to the group, then find the group's numeric
  ID (negative number like `-1001234567890`).
- For **direct messages**: Your personal user ID (positive number).

Add to `~/.hermes/.env`:
```
TELEGRAM_HOME_CHANNEL=123456789
```

**Pitfall**: The cron job's `deliver_chat_id` field must be set to this same
value. If left empty, the cron job's Telegram delivery silently fails with
no error. The `setup_content_workforce.py` script auto-populates this from
the `TELEGRAM_HOME_CHANNEL` environment variable.

## Usage

```bash
# After the content-writer produces draft.md
python3 ~/.hermes/skills/autonomous-ai-agents/telegram-approval-gateway/telegram_approval_gateway.py \
  ~/workspace/drafts/draft.md \
  ~/workspace/briefs/brief.md
```

### Return codes

| Exit code | Meaning |
|-----------|---------|
| 0 | Approved — proceed to publishing |
| 1 | Error (credentials missing, send failed, etc.) |
| 2 | Rejected — feedback is printed to stdout |
| 3 | Timeout — no response within 24 hours |

### In the content pipeline

The gateway is invoked automatically by the `content-pipeline` coordinator
skill after the writer sub-agent produces a draft. The coordinator:

1. Calls `telegram_approval_gateway.py draft.md brief.md`
2. If exit code 0: delegates to the publisher sub-agent
3. If exit code 2: sends feedback back to the writer for revision
4. If exit code 3: escalates to email or Discord (if configured)

## How It Works

1. **Sends the draft** as a formatted Telegram message with a preview
   (first 3,500 chars) and inline buttons:
   - ✅ Approve & Publish
   - ❌ Request Changes

2. **Sends the full draft** as a `.md` document attachment (for readability)

3. **Polls for callbacks** using `getUpdates` with long polling. When the
   reviewer clicks a button:
   - **Approve**: Sends a confirmation message and returns exit code 0
   - **Reject**: Sends a follow-up asking for feedback, waits for the
     user to reply, then returns exit code 2 with the feedback text

4. **Timeout**: If no response within 24 hours (configurable via
   `APPROVAL_TIMEOUT_SECONDS`), returns exit code 3

## Integration

This skill works with:
- **content-pipeline** — coordinator invokes this gateway after draft generation
- **content-writer** — receives feedback from rejection for revision
- **wp-publisher** — triggered on approval to publish to WordPress
- **cron_scheduler** — ensures the pipeline runs on schedule with human oversight

## Customization

### Timeout

Edit `APPROVAL_TIMEOUT_SECONDS` in the script (default: 86400 = 24 hours).

### Message format

Edit `send_approval_message()` to customize the Telegram message format,
add more buttons, or change the caption text.

### Escalation

For timeout handling, modify the `main()` function to add fallback delivery:
- Email via `himalaya` skill
- Discord notification
- Desktop notification via `terminal`
