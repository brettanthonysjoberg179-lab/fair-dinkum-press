---
name: content-test-suite
description: "Automated test suite for the content generation workforce: happy paths, edge cases, adversarial injections, and guardrail compliance."
version: 1.0.0
author: Generated for content workforce
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [testing, evaluation, ci-cd, content, pytest]
    related_skills: [content-pipeline, content-researcher, content-writer, telegram-approval-gateway]
---

# Content Workforce Test Suite

Pytest-based evaluation harness for the content generation pipeline. Tests cover
four categories: Happy Paths, Edge Cases, Adversarial Injections, and Guardrail
Compliance.

## Usage

```bash
# Install test dependencies
pip install pytest pytest-asyncio

# Run the full suite
cd ~/.hermes/skills/autonomous-ai-agents/content-test-suite
pytest tests/ -v

# Run specific category
pytest tests/ -v -k "happy"
pytest tests/ -v -k "edge"
pytest tests/ -v -k "adversarial"
pytest tests/ -v -k "guardrail"

# Run with JSON output for CI/CD
pytest tests/ --json-report --json-report-file=results.json
```

## Test Categories

| Category | Purpose | Threshold |
|----------|---------|-----------|
| Happy Paths | Verify correct pipeline execution with valid inputs | >95% pass |
| Edge Cases | Verify graceful degradation with missing/conflicting inputs | >90% pass |
| Adversarial | Verify resilience against injection and manipulation | 100% pass |
| Guardrail | Verify forbidden actions are refused | 100% pass |

## Architecture

```
content-test-suite/
├── fixtures/
│   ├── happy_paths.json          # Standard pipeline scenarios
│   ├── edge_cases.json           # Missing data, API failures
│   ├── adversarial.json          # Prompt injection, goal manipulation
│   └── guardrail_violations.json # Policy violation attempts
├── tests/
│   ├── conftest.py               # Pytest fixtures and shared utils
│   ├── test_happy_paths.py       # Category 1
│   ├── test_edge_cases.py        # Category 2
│   ├── test_adversarial.py       # Category 3
│   ├── test_guardrails.py        # Category 4
│   └── test_runner.py            # Orchestration + LLM-judge evaluation
├── test_runner.py                # Main runner script
└── SKILL.md                       # This file
```

See the fixture files and test scripts for full implementation details.
