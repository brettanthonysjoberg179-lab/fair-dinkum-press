---
name: content-researcher
description: "Researcher sub-agent for content workforce: discovers trending topics, fetches sources, and outputs structured, source-attributed briefs."
version: 1.0.0
author: Generated for content workforce
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [research, content, briefs, grounded-citations, web]
    related_skills: [grounded-citations, arxiv, rss-feeds, xurl]
---

# Content Researcher Sub-Agent

Discovers trending topics in your domain, fetches supporting sources, and outputs
structured research briefs with inline source attribution via the grounded-citations
ledger. Designed to be invoked by the content_writer skill or a coordinator agent.

## Prerequisites

- `grounded-citations` skill installed (for source ledger)
- Web search/extraction tools available (`web_search`, `web_extract`)
- Optional: `rss-feeds` skill for feed-based topic discovery
- Optional: `xurl` skill for X/Twitter trend monitoring

## Usage

```bash
# Direct invocation in chat
hermes chat -q "Research trending AI topics from the last 48 hours"

# As a delegated sub-agent (from coordinator)
delegate_task(goal="Research trending AI topics from the last 48 hours", context="...")
```

## Workflow

### Step 1 — Reset the citation ledger
```bash
# Resolve the correct path to sources.py across profiles
S=$(find ~/.hermes/skills -path "*/grounded-citations/scripts/sources.py" 2>/dev/null | head -1)
python "$S" reset
```

### Step 2 — Discover trending topics
Use multiple signals in parallel:
- **Web search**: `web_search("trending AI 2026", limit=10)` → extract URLs
- **RSS feeds**: If `rss-feeds` is installed, `rss_read("techcrunch", "the-verge")`
- **X/Twitter**: If `xurl` is configured, `xurl search "#AI -n 20` for recent posts
- **arxiv**: `arxiv search "machine learning" category=cs.LG` for recent papers

### Step 3 — Fetch and register sources
For each URL discovered:
```bash
# Register every URL in the ledger BEFORE writing any prose
python "$S" add <url> --title "<title>"
```

Then extract full content:
```bash
web_extract([url])
```

### Step 4 — Synthesize the brief
Produce a structured brief in this format:

```markdown
# Research Brief: <Topic>

## Trending Claims
1. [Claim] — supported by [1][2]
2. [Claim] — supported by [3][unverified]

## Key Sources
- [1] <Title> — <URL>
- [2] <Title> — <URL>
- [3] <Title> — <URL>

## Contradictions
- Source [1] claims X; source [3] claims Y.

## Brief for Writer
- Target angle: <angle summary>
- Hook: <hook sentence>
- Key points to expand: <3-5 bullet points>
- Cited sources: [1][2][3]
```

```bash
python "$S" render --replace-in brief.md
```

Then verify:
```bash
python "$S" verify brief.md --min-coverage 0.5
```

**Pitfall**: The `verify` regex `\[(\d{1,4})\]` misparses bracketed years in
titles (e.g., `[2026]` in a source title) as citations. Remove bracketed
years from titles before registering, or confirm the exit code is 0
(`citations OK`) and treat the warning as expected noise.

## Topic Discovery Templates

### General research prompt
```
Research <topic> as of the current date. Focus on:
1. Breaking developments in the last 7 days
2. Expert consensus vs. controversy
3. Key data points, statistics, or findings
4. Contradictions between sources
5. Primary sources (avoid secondhand summaries)

Use web_search with limit=10, then web_extract on the top 5 results.
Register every URL in the citation ledger before writing any prose.
```

### Industry-specific prompts
- **AI/Tech**: "What are the biggest AI breakthroughs announced this week?"
- **Finance**: "Daily market-moving news and analysis"
- **Health**: "Recent medical research findings and public health updates"
- **Business**: "Company announcements, funding rounds, and market trends"

## Output Format

The skill produces `brief.md` files in the workspace directory. Each brief:
- Uses inline numeric citations `[n]` from the ledger (never invented)
- Contains a "Brief for Writer" section with actionable angles
- Flags any `[unverified]` claims
- Includes a Sources section rendered from the ledger via `sources.py render --replace-in`

**Pitfall**: Sub-agents may resolve `$HOME`/`~` differently from the parent
session. Always write to the explicit absolute path `$HERMES_HOME/workspace/`
(not `~/workspace/`) to ensure the coordinator and writer can find the file.

## Integration

This skill feeds into:
- **content_writer** — consumes `brief.md` + brand guidelines → draft
- **cron_scheduler** — triggers on schedule (e.g., daily at 8 AM)
- **telegram_gateway** — sends briefs to Telegram for review
