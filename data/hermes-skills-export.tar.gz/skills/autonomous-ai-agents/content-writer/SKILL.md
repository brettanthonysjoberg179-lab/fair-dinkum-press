---
name: content-writer
description: "Writer sub-agent: takes research briefs + brand guidelines, generates platform-specific drafts with structural rules and self-edit pass."
version: 1.0.0
author: Generated for content workforce
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [content, writing, drafts, brand-voice, self-edit]
    related_skills: [content-researcher, grounded-citations, obsidian]
---

# Content Writer Sub-Agent

Takes a research brief and brand voice guidelines, produces platform-specific
drafts following structural rules (headers, word limits, CTAs), and runs a
self-edit pass for brand voice compliance.

## Prerequisites

- `content-researcher` skill (or a `brief.md` file with source-attributed claims)
- `grounded-citations` skill (for citation ledger passthrough)
- Brand guidelines stored in Notion, Obsidian, or a local markdown file

## Usage

```bash
# Direct invocation
hermes chat -q "Write a 1200-word LinkedIn article from the research brief at ~/workspace/brief.md"

# As a delegated sub-agent (from coordinator)
delegate_task(
  goal="Write a 1200-word LinkedIn article from the research brief",
  context="Brief is at ~/workspace/brief.md. Brand voice: conversational, data-driven. Target platform: LinkedIn long-form. Must include CTA encouraging comments."
)
```

## Workflow

### Step 1 — Load inputs

1. **Research brief** (`brief.md`): Contains trending claims, key sources,
   and a "Brief for Writer" section with angles and hook.
2. **Brand style guide**: Loaded from one of:
   - Notion DB (via `notion` skill) — requires `NOTION_API_KEY`
   - Obsidian vault (via `obsidian` skill) — requires `OBSIDIAN_VAULT_PATH`
   - Local file: `brand_guide.md` in the project root

### Step 2 — Draft following structural rules

Based on platform configuration (default: LinkedIn long-form article):

- **H2/H3 structure** with clear section hierarchy
- **Word target**: 800-1,200 words (configurable)
- **CTA placement**: One CTA at the end of the article, optionally one mid-article
- **Citation carry-through**: Inline `[n]` citations from the brief are preserved
  by reading the brief's cited source IDs from the ledger — never inventing
  new source IDs or rearranging them
- **Hook**: The brief's hook sentence becomes the opening paragraph

**Pitfall**: The writer sub-agent must reuse the SAME citation ledger as the
researcher (same `sources.py` instance). If the ledger is reset between
tasks, all `[n]` IDs in the brief become dangling references.
Delegate with `HERMES_CITATION_LEDGER` set to the same path, or ensure
the sub-agent inherits the parent's `$HERMES_HOME/cache/citations/ledger.json`.

### Step 3 — Self-edit pass

After the first draft, the agent runs a self-edit pass checking:

1. **Brand voice compliance**: Does the tone match the style guide?
2. **Citation integrity**: All `[n]` citations in the draft exist in the ledger?
3. **Structural rules**: Headers balanced? Word count in range? CTA present?
4. **Readability**: Short paragraphs? Clear transitions? No jargon without context?

### Step 4 — Output

The skill produces `draft.md` in the workspace directory with this structure:

```markdown
# <Article Title>

<Opening with hook>

## <H2 Section>

<Content with [n] citations>

## <H2 Section>

<Content>

<CTA>

## Sources
[rendered from citation ledger]
```

## Platform Configurations

### LinkedIn Long-Form Article
- Tone: Professional but conversational
- Word target: 800-1,200
- Structure: Problem → Evidence → Implications → CTA
- CTA example: "What's your take on [topic]? Share your thoughts below."

### Twitter Thread
- Tone: Punchy, hook-heavy
- Format: 5-10 tweets
- Each tweet: 200-250 chars
- Last tweet: CTA with link

### Blog Post (SEO)
- Tone: Authoritative, educational
- Word target: 1,500-2,500
- Structure: H1 → Intro → H2 sections → Conclusion → CTA
- SEO: Keywords in H1 and first paragraph

### Newsletter
- Tone: Friendly, insider
- Word target: 500-800
- Structure: Opening → Main insight → Supporting data → CTA

## Brand Guide Template

Store as `brand_guide.md` or in Notion/Obsidian:

```markdown
# Brand Voice: <Brand Name>

## Tone
- Professional but approachable
- Data-driven, not anecdotal
- Confident but not arrogant

## Structure Rules
- H2 every 2-3 paragraphs
- Bullet lists OK for lists of 3+ items
- One CTA per draft (at the end)
- No passive voice

## Style Preferences
- Use em dashes — not parentheses
- Sentence length: avg 15-20 words
- Link to primary sources
- No jargon without explanation
```

## Integration

This skill consumes:
- **content-researcher** output (`brief.md`)
- **brand_guide.md** (from Notion/Obsidian/local)

This skill feeds into:
- **telegram_approval_gateway** — sends `draft.md` for review
- **wp_publisher** — publishes approved drafts to WordPress
- **cron_scheduler** — triggers on schedule
