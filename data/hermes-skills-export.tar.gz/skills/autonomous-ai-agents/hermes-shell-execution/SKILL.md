---
name: hermes-shell-execution
description: "Run shell commands when terminal is unavailable."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, terminal, shell, execution, fallback, delegate, cron]
    related_skills: [hermes-agent, claude-code, codex]
---

# Hermes Shell Execution

Provides a fallback sequence for running shell commands when the `terminal` tool is unavailable or blocked in a Hermes session (e.g., Docker sandbox not running, toolset restrictions).

## When to Use

Use this skill when:
- A user asks you to run a command, install software, or execute a script
- The `terminal` tool returns "Tool does not exist" or similar unavailability
- `execute_code` fails with `EnvironmentConnectionError: Docker executable not found`
- You need fire-and-forget execution without blocking the conversation

## Execution Fallback Sequence

Try these in order. Stop at the first one that works.

### 1. Direct terminal (preferred when available)

```
terminal(command="pip install honcho", timeout=60)
```

If the tool exists and the environment is healthy, this is the fastest path.

### 2. execute_code with subprocess

```python
import subprocess, sys
result = subprocess.run([sys.executable, '-m', 'pip', 'install', 'honcho'], capture_output=True, text=True, timeout=120)
print(result.stdout)
print(result.stderr)
```

Works when Python is available and the subprocess can reach the network.
Fails when the Docker sandbox backing `execute_code` is not running.

### 3. delegate_task sub-agent (most reliable fallback)

Spawn a sub-agent that has its own execution environment:

```
delegate_task(tasks=[{
  goal: "Run `pip install honcho` and report the result",
  context: "Install the honcho Python package and verify with `pip show honcho`",
  output_schema: {properties: {installed: {type: boolean}, version: {type: string}}}
}])
```

Sub-agents often have access to execution capabilities the parent session lacks
because they run in a separate runtime context. Use this when both `terminal`
and `execute_code` fail.

### 4. cronjob_manage with no_agent (async fire-and-forget)

For long-running or non-blocking tasks:

```
cronjob_manage(action="create", name="install-package", no_agent=true,
  schedule="in 1m", script="pip install honcho 2>&1 && pip show honcho")
```

The job runs in the Hermes scheduler. Output is saved locally. Use
`cronjob_manage(action="list")` to check completion status.

**Note:** `deliver` must target a messaging platform (e.g., `telegram`) to
receive output outside the CLI session. Default `deliver` is local-only.

## Pitfalls

- **Don't assume Docker is always down.** If `execute_code` fails once with
  Docker errors, it may be a transient sandbox issue. Try once more after a
  brief pause before falling back to delegate_task.

- **When both `terminal` and `execute_code` fail with Docker errors**, the
  `cronjob_manage` tool can schedule asynchronous installations. Output is saved
  locally but not delivered back into the current session. Use `deliver='telegram'`
  or another gateway platform to receive output outside the CLI session.

- **Cron job scripts require proper path formatting.** The script path
  `~/.hermes/scripts/<command>` is expected; bare commands like `pip install honcho`
  may produce 'Script not found' errors unless the script resides in the Hermes
  scripts directory or an absolute path is used.

- **Sub-agents can't ask questions.** If a command might prompt for input
  (e.g., overwrite confirmation), add `-y` or `--yes` flags to the command
  before passing it to a sub-agent.
