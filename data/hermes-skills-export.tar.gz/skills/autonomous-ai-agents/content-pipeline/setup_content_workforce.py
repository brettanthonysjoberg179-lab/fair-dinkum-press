#!/usr/bin/env python3
"""
Content Workforce Setup Script

Bootstraps the full content generation pipeline in Hermes Agent:
1. Creates workspace directory structure
2. Generates a brand guide template
3. Creates the cron job configuration
4. Validates all required environment variables

Usage:
  python3 setup_content_workforce.py [--topic "AI developments"] [--platform linkedin]

Environment variables required (set in ~/.hermes/.env):
  - Telegram: TELEGRAM_BOT_TOKEN, TELEGRAM_HOME_CHANNEL
  - WordPress: WP_SITE_URL, WP_USERNAME, WP_APP_PASSWORD (optional, for publishing)
  - Notion: NOTION_API_KEY (optional, for brand guide storage)
"""

import os
import sys
import json
import time
import argparse
from pathlib import Path

HERMES_HOME = Path(os.environ.get("HERMES_HOME", str(Path.home() / ".hermes")))
WORKSPACE = Path(os.environ.get("BH_AGENT_WORKSPACE", str(Path.home() / ".hermes" / "workspace")))

SKILLS_DIR = HERMES_HOME / "skills" / "autonomous-ai-agents"
CRON_DIR = HERMES_HOME / "cron"


def create_workspace():
    """Create the workspace directory structure."""
    dirs = [
        WORKSPACE,
        WORKSPACE / "briefs",
        WORKSPACE / "drafts",
        WORKSPACE / "published",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    print(f"✓ Created workspace at {WORKSPACE}")
    return WORKSPACE


def create_brand_guide(topic="AI and machine learning", tone="conversational, data-driven"):
    """Generate a default brand guide template."""
    guide_path = WORKSPACE / "brand_guide.md"

    if guide_path.exists():
        print(f"✓ Brand guide already exists at {guide_path}")
        return guide_path

    template = f"""# Brand Voice Guide

## Brand: Content Workforce
## Default Topic: {topic}
## Tone: {tone}

## Voice Attributes
- **Professional but approachable** — speak like an expert who's also a human
- **Data-driven** — every claim should reference a source or dataset
- **Confident but not arrogant** — acknowledge uncertainty where it exists
- **Actionable** — always end with a clear next step or CTA

## Structural Rules
- Use H2 for main sections, H3 for sub-points
- Max 3 consecutive paragraphs without a header
- Bullet lists for 3+ items
- One CTA per draft (at the end, not mid-article)
- Paragraphs: 2-4 sentences max
- Sentence length: average 15-20 words

## Style Preferences
- Use em dashes — not parentheses
- Use numerals for numbers 10+ (write "15" not "fifteen")
- Bold key insights, but sparingly
- Link to primary sources, not secondary summaries
- No jargon without a brief explanation
- Use "people" instead of "users" when referring to general audience

## Citation Policy
- Every factual claim carries an inline `[n]` citation
- [unverified] only for claims that genuinely can't be sourced
- Sources block auto-rendered from the citation ledger

## Platform Adaptations
- **LinkedIn**: Professional tone, 800-1,200 words, end with engagement CTA
- **Twitter/X**: Punchy hooks, 200-250 chars per tweet, thread format
- **Blog**: Authoritative, 1,500-2,500 words, SEO keyword in H1
- **Newsletter**: Friendly insider tone, 500-800 words, personal anecdote opener
"""

    guide_path.write_text(template, encoding="utf-8")
    print(f"✓ Created brand guide at {guide_path}")
    return guide_path


def check_env_var(name, description, required=True):
    """Check if an environment variable is set."""
    value = os.environ.get(name)
    if value:
        print(f"  ✓ {name}: set")
        return True
    else:
        status = "✗ REQUIRED" if required else "  (optional, not set)"
        print(f"  {status} {name}: {description}")
        return False if required else None


def validate_environment():
    """Validate all required environment variables."""
    print("\nChecking environment variables:")
    print("\n  Telegram (required for approval gateway):")
    check_env_var("TELEGRAM_BOT_TOKEN", "Your Telegram bot token from @BotFather")
    check_env_var("TELEGRAM_HOME_CHANNEL", "Target Telegram chat/channel ID")

    print("\n  WordPress (optional, for auto-publishing):")
    check_env_var("WP_SITE_URL", "Your WordPress site URL", required=False)
    check_env_var("WP_USERNAME", "WordPress username", required=False)
    check_env_var("WP_APP_PASSWORD", "WordPress Application Password", required=False)

    print("\n  Notion (optional, for brand guide storage):")
    check_env_var("NOTION_API_KEY", "Your Notion integration API key", required=False)


def create_cron_job(topic, platform):
    """Create the cron job configuration for the daily content pipeline."""
    cron_config_path = CRON_DIR / "jobs.json"

    # Default schedule: weekdays at 8 AM
    schedule = "0 8 * * 1-5"

    job_config = {
        "id": "content-pipeline-daily",
        "name": "daily-content-pipeline",
        "prompt": (
            f"Run the content-pipeline coordinator skill. "
            f"Topic: {topic}. Platform: {platform}. "
            f"Research briefs via content-researcher, write drafts via content-writer, "
            f"send for Telegram approval, and publish approved drafts to WordPress. "
            f"Output to workspace directory."
        ),
        "skills": [
            "content-pipeline",
            "content-researcher",
            "content-writer",
            "telegram-approval-gateway",
            "grounded-citations",
        ],
        "schedule": {
            "kind": "cron",
            "expr": schedule,
            "display": f"every weekday at 08:00",
        },
        "timeout": 300,
        "deliver": "telegram",
        "deliver_chat_id": os.environ.get("TELEGRAM_HOME_CHANNEL", ""),
        "enabled": True,
        "state": "enabled",
        "context": {
            "topic": topic,
            "platform": platform,
            "workspace": str(WORKSPACE),
        },
    }

    # Read existing jobs or create new
    existing = {"jobs": []}
    if cron_config_path.exists():
        try:
            parsed = json.loads(cron_config_path.read_text())
            if isinstance(parsed, dict):
                if "jobs" in parsed:
                    existing = parsed
                else:
                    # old format: top-level keys are job names
                    for k, v in parsed.items():
                        if isinstance(v, dict) and "schedule" in v:
                            existing["jobs"].append({**v, "name": k})
        except json.JSONDecodeError:
            existing = {"jobs": []}

    # Remove any existing daily-content-pipeline job, then append
    existing["jobs"] = [
        j for j in existing["jobs"]
        if j.get("name") != "daily-content-pipeline"
    ]
    existing["jobs"].append(job_config)
    existing["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime())

    cron_config_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
    print(f"✓ Created cron job 'daily-content-pipeline' at {cron_config_path}")
    print(f"  Schedule: {schedule} (weekdays at 8:00 AM)")
    print(f"  Topic: {topic}")
    print(f"  Platform: {platform}")
    print(f"  Delivery: Telegram (chat_id: {os.environ.get('TELEGRAM_HOME_CHANNEL', 'NOT SET')})")

    return job_config


def create_pipeline_prompt():
    """Create the reusable prompt template for the content pipeline."""
    template_path = SKILLS_DIR / "content-pipeline" / "templates" / "pipeline_prompt.md"
    template_path.parent.mkdir(parents=True, exist_ok=True)

    template = """# Content Pipeline Execution Template

## Role
You are the coordinator for a multi-agent content generation pipeline.
You coordinate between specialized sub-agents using delegate_task.

## Task
{topic}

## Platform
{platform}

## Workflow

### Phase 1: Research
Delegate to the research sub-agent:
- Run web_search for "{topic}" focusing on the last 48 hours
- Extract full content from the top 5 sources
- Register every URL in the grounded-citations ledger
- Produce a structured brief.md with:
  - Trending claims with inline citations
  - Key sources list
  - Contradictions between sources
  - "Brief for Writer" section with angles, hook, and key points
- Output to: {workspace}/briefs/{timestamp}_brief.md

### Phase 2: Writing
Delegate to the writer sub-agent:
- Read brief.md and brand_guide.md
- Write a {word_count}-word {platform} article
- Follow brand voice and structural rules
- Preserve all inline citations
- Include a CTA (at the end for articles, as last tweet for threads)
- Run self-edit pass for brand compliance
- Output to: {workspace}/drafts/{timestamp}_draft.md

### Phase 3: Review & Publish
Send the draft to Telegram for review using the telegram_approval_gateway script.
- If approved: publish to WordPress as draft post
- If rejected: relay feedback to writer, regenerate
- If timeout: escalate notification

## Constraints
- Every factual claim must carry an inline [n] citation
- Never invent URLs or sources — use only ledger IDs
- Flag claims you can't source as [unverified]
- Keep the draft within {word_count} words (±10%)
- Match the brand voice: {tone}
"""

    template_path.write_text(template, encoding="utf-8")
    print(f"✓ Created pipeline prompt template at {template_path}")
    return template_path


def print_next_steps():
    """Print instructions for next steps."""
    print("\n" + "=" * 60)
    print(" CONTENT WORKFORCE SETUP COMPLETE")
    print("=" * 60)
    print(f"\nWorkspace: {WORKSPACE}")
    print(f"Skills installed:")
    print(f"  • content-researcher  (web research → briefs)")
    print(f"  • content-writer      (briefs → drafts)")
    print(f"  • content-pipeline    (coordinator)")
    print(f"  • telegram-approval-gateway (review gateway)")
    print(f"\nCron job: daily-content-pipeline")
    print(f"  Schedule: 0 8 * * 1-5 (weekdays at 8:00 AM)")
    print(f"\nNext steps:")
    print(f"  1. Set TELEGRAM_BOT_TOKEN and TELEGRAM_HOME_CHANNEL in ~/.hermes/.env")
    print(f"  2. (Optional) Set WordPress credentials for auto-publishing")
    print(f"  3. Edit brand_guide.md: {WORKSPACE / 'brand_guide.md'}")
    print(f"  4. Start the gateway: hermes gateway run")
    print(f"  5. Test manually: hermes cron run daily-content-pipeline")
    print(f"  6. Or chat: 'hermes chat -q \"Run the content pipeline for today's AI news\"'")
    print("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="Set up the Hermes content generation workforce"
    )
    parser.add_argument(
        "--topic",
        default="latest AI and machine learning developments",
        help="Default research topic for the pipeline"
    )
    parser.add_argument(
        "--platform",
        default="linkedin",
        choices=["linkedin", "twitter", "blog", "newsletter"],
        help="Default content platform"
    )
    parser.add_argument(
        "--schedule",
        default="0 8 * * 1-5",
        help="Cron schedule expression (default: weekdays at 8 AM)"
    )
    args = parser.parse_args()

    print("=" * 60)
    print(" SETTING UP CONTENT WORKFORCE")
    print("=" * 60)

    # Step 1: Create workspace
    print("\n1. Creating workspace structure...")
    create_workspace()

    # Step 2: Create brand guide
    print("\n2. Creating brand guide template...")
    create_brand_guide(args.topic, "conversational, data-driven")

    # Step 3: Validate environment
    print("\n3. Checking environment...")
    validate_environment()

    # Step 4: Create cron job
    print("\n4. Creating cron job...")
    create_cron_job(args.topic, args.platform)

    # Step 5: Create pipeline prompt template
    print("\n5. Creating pipeline templates...")
    create_pipeline_prompt()

    # Done
    print_next_steps()


if __name__ == "__main__":
    main()
