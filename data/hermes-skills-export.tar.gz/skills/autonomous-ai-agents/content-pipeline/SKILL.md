---
name: content-pipeline
description: "Coordinator skill: orchestrates research → writing → review → publish pipeline with error handling and retry logic."
version: 1.0.0
author: Generated for content workforce
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [orchestration, coordinator, pipeline, content, automation]
    related_skills: [content-researcher, content-writer, telegram-approval-gateway]
---

# Content Pipeline Coordinator

Orchestrates the full content generation pipeline:
**Research → Writing → Telegram Approval → Publishing**

This skill defines the coordination logic. It can be used directly as a prompt
template or deployed as a skill that triggers via cron.

## Architecture

```
[Coordinator: content-pipeline]
       ↓
  ┌─────────────┐
  │ Researcher  │  → brief.md
  └─────────────┘
       ↓
  ┌─────────────┐
  │   Writer    │  → draft.md
  └─────────────┘
       ↓
  ┌─────────────┐
  │  Telegram   │  → Approval / Rejection
  └─────────────┘
       ↓
  ┌─────────────┐
  │  Publisher  │  → WordPress / CMS
  └─────────────┘
```

## How It Works

The coordinator uses `delegate_task` to spawn specialized sub-agents:

### Phase 1: Research
```python
# Researcher sub-agent — lightweight, focused on source discovery
delegate_task(
    goal="Research trending AI topics from the last 48 hours and produce a structured brief.md with inline source citations",
    context="Topic: AI and machine learning. Use web_search, web_extract, and cite every source. Output to $HERMES_HOME/workspace/briefs/",
    role="leaf"
)
```

### Phase 2: Writing
```python
# Writer sub-agent — takes brief + brand guide, produces draft
delegate_task(
    goal="Write a 1200-word LinkedIn article from the research brief",
    context="Brief is at $HERMES_HOME/workspace/briefs/. Brand voice: conversational, data-driven. Use grounded-citations ledger. Output to $HERMES_HOME/workspace/drafts/",
    role="leaf"
)
```

### Phase 3: Telegram Review
The coordinator calls the `telegram_approval_gateway` script to:
1. Send the draft to a Telegram chat
2. Wait for approval or revision request
3. If rejected, loop back to the writer with feedback

### Phase 4: Publish
If approved:
```python
delegate_task(
    goal="Publish the approved draft at $HERMES_HOME/workspace/drafts/ to WordPress as a draft post",
    context="Use wp_create_post tool with status=draft. Map categories and tags.",
    role="leaf"
)
```

## Orchestration Template

When invoked, the coordinator follows this procedural template:

```
PIPELINE EXECUTION: <topic>

1. RESEARCH
   - Delegate to content-researcher sub-agent
   - Pass: topic keywords, time window, target depth
   - Receive: brief.md with source-attributed claims

2. WRITE
   - Delegate to content-writer sub-agent
   - Pass: brief.md path, brand_guide.md path, platform config
   - Receive: draft.md with CTA and citations

3. REVIEW
   - Send draft.md to Telegram via approval gateway
   - If approved → proceed to publish
   - If rejected → relay feedback to writer, regenerate

4. PUBLISH
   - Delegate to publisher sub-agent
   - Pass: draft.md, CMS credentials from .env
   - Receive: post URL and ID

5. ARCHIVE
   - Save final post to Obsidian vault as published content
   - Log to Notion database with metadata
   - Update citation ledger
```

## Cron Integration

```yaml
# In ~/.hermes/cron/jobs.json — schedule must be a structured object:
{
  "jobs": [
    {
      "name": "daily-content-pipeline",
      "schedule": {
        "kind": "cron",
        "expr": "0 8 * * 1-5",
        "display": "every weekday at 08:00"
      },
      "prompt": "Run the content-pipeline coordinator skill...",
      "skills": ["content-pipeline", "content-researcher", "content-writer", "telegram-approval-gateway", "grounded-citations"],
      "timeout": 300,
      "deliver": "telegram",
      "deliver_chat_id": "<TELEGRAM_HOME_CHANNEL_VALUE>",
      "enabled": true
    }
  ]
}
```

The `deliver_chat_id` must be populated from `TELEGRAM_HOME_CHANNEL`
in `~/.hermes/.env`. Use the setup script to auto-generate this.

## Error Handling

- **Research failure**: Retry once with expanded search terms
- **Writing failure**: Fall back to outline-only output
- **Telegram timeout**: Escalate to email or Discord after 24 hours
- **Publish failure**: Save as draft.md and alert user
- **Cron `deliver_chat_id` empty**: The cron job's `deliver_chat_id` must be
  set to the value of `TELEGRAM_HOME_CHANNEL`. If it is empty, Telegram
  delivery silently fails. The setup script auto-populates this from the
  environment — re-run `setup_content_workforce.py` after setting the env var.
- **Sub-agent workspace mismatch**: Sub-agents may resolve `~` or `$HOME`
differently from the parent. Always use `$HERMES_HOME/workspace/` in delegate
context strings, never `~/workspace/`.

## CLI Usage

```bash
# Run the full pipeline once
hermes chat -q "Run the content pipeline for today's AI news. Output to ~/workspace/"

# Run with specific topic
hermes cron run daily-content --payload '{"topic": "AI regulation"}'

# Check pipeline status
hermes cron list
```
