---
name: multi-agent-tooling
description: "Add tools and skills to all agents in a workforce project."
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [multi-agent, tooling, skills, composio, workforce]
---

# Multi-Agent Tooling

Add a tool (e.g. composio) and its corresponding skill to every agent in a multi-agent workforce project.

## Scope

Use when:
- Adding a new tool to `allowed_tools` across all agents
- Adding a new `load_skill()` call to all agent `__init__` methods
- Auditing which agents have a given tool or skill
- Populating or repairing an empty `agents/__init__.py` package init

## Procedure

### 1. Find all agent files

```bash
find agents/ -name "*.py" -not -name "__init__.py" -not -name "workflows.py"
```

### 2. Audit current state

```bash
# Count agents with/without the tool
grep -rl '"tool_name"' agents/ | wc -l

# List agents missing the tool
for f in $(find agents/ -name "*.py" -not -name "__init__.py"); do
  grep -q '"tool_name"' "$f" || echo "MISSING: $f"
done
```

### 3. Patch `allowed_tools`

For each agent file missing the tool, add it to the `allowed_tools` list:

```python
allowed_tools = ["ollama", "composio", "airtable_read", ...]
```

Use `patch` for targeted edits — match the exact list string and prepend/insert the new tool.

### 4. Patch `load_skill()` in `__init__`

For each agent, add `self.load_skill("tool_name")` inside `__init__`, after config assignments and before the first method:

```python
def __init__(self, config: Dict[str, Any]):
    super().__init__(config)
    self.some_config = config.get("some_config", default)
    self.load_skill("tool_name")  # <-- add here
```

### 5. Verify compilation

Use the project venv when one exists — system `python3` may lack installed dependencies:

```bash
# With project venv
.venv/bin/python -m py_compile agents/__init__.py agents/**/*.agent.py

# Without venv, system python3 (syntax-only, no imports resolved)
find agents/ -name "*.py" -exec python3 -m py_compile {} \;
```

Fix any `SyntaxError` before proceeding.

### 6. Final audit

```bash
# Confirm all agents have the tool
grep -rl '"tool_name"' agents/ | wc -l

# Confirm all agents have the skill
grep -rl 'load_skill("tool_name")' agents/ | wc -l
```

## LLM Backend Integration

When integrating multiple LLM backends (Ollama, Gemini, Hugging Face) into a workforce:

1. **Mirror the client interface**: Each backend client (`GeminiClient`, `HFClient`, `OllamaClient`) must implement the same async methods: `generate()`, `chat()`, `structured_output()`, `count_tokens()`, `close()`.
2. **Agent class pattern**: Each agent (`GeminiAgent`, `HFAgent`) inherits `BaseAgent`, sets `self.agent_id`, `self.allowed_tools`, `self.read_permissions`, `self.write_permissions`, and implements `run()`.
3. **Register in orchestrator**: Add the client instantiation (`self.gemini = GeminiClient()`) and the new tool name to `allowed_tools`.
4. **MCP server registration**: Import and add to `agents_config` dict in `mcp_server/main.py`.
5. **Environment variables**: Set all API keys in `.env` — `GEMINI_API_KEY`, `HF_TOKEN`, `HF_MODEL`, `OLLAMA_MODEL`. The MCP `mcp_config.json` must also reference them.

## Pitfalls

- **Patch tool eats method signatures**: When inserting `load_skill()` calls into `__init__`, the `patch` tool may consume the next line (e.g. `async def execute(self, ...)`) if your `old_string` ends at the last config line and the replacement doesn't include a blank line + the method signature. Result: `SyntaxError: 'await' outside async function`. **Fix**: Always include a trailing blank line in your replacement string — see the memory rule about including the next method's `async def` signature. Verify with `py_compile` immediately after each batch.

- **Class names vs file names diverge**: Agent file names use snake_case (e.g. `seo_research_agent.py`) but class names use PascalCase with acronyms that don't follow naive casing (e.g. `SEOResearchAgent`, `QAAgent`, `WordPressIntelligenceAgent`, `TikTokIntelligenceAgent`). **Fix**: Before writing `__init__.py` imports, scan every file for its actual class name with a regex sweep: `re.findall(r'class\s+(\w+)', content)`. Never assume class names from file names — Pyright will flag unknown import symbols.

- **HF inference API DNS**: `api-inference.huggingface.co` may not resolve even when `huggingface.co` works. **Fix**: Verify with `socket.getaddrinfo('api-inference.huggingface.co', 443)`. Model discovery via `huggingface_hub` works, but inference is DNS-blocked. Set `HF_API_URL` to a working endpoint.

- **`None` defaults in typed signatures**: Python type checkers (Pyright) flag `model = model or self.default_model` when `model: str = None` because `None` is not assignable to `str`. **Fix**: Use `model = model if model is not None else self.default_model` instead of `or`. This applies to all optional `str`/`List` parameters.

- **Patch ambiguity in `__init__`**: When multiple agents have similar `__init__` bodies (e.g. `self.load_skill("composio_tooling")` followed by a method), the `patch` tool may fail with "Could not find a match" because the `old_string` isn't unique enough. **Fix**: Include more surrounding context (2-3 lines before and after) to make the match unique, or use `replace_all=false` with the most specific string possible.

- **Agents without `__init__`**: Some agents inherit `__init__` from `BaseAgent` and don't define their own. To add `load_skill()`, you must create a full `__init__` with `super().__init__(config)` (or `super().__init__(name, role)` for non-config agents). Check if `__init__` exists before patching — if the first method is `async def execute`, there's no `__init__`.

- **Class-level vs instance-level `allowed_tools`**: Some agents define `allowed_tools` as a class attribute (outside `__init__`), others as `instance attribute (`self.allowed_tools = [...]` inside `__init__`). Patch whichever is present. If you try to patch `self.allowed_tools` but the file uses class-level, the patch will fail silently.

- **Sub-agent directories**: Agents may be nested one or two levels deep (e.g. `agents/research/agent.py`, `agents/distribution/publisher_agent.py`). Use `find` with `-not -name "__init__.py"` to catch all of them.

- **Cache files**: `__pycache__/*.pyc` files may cause stale reads. Ignore them — they regenerate on next import.

- **Empty `__init__.py` files**: A 0-byte `agents/__init__.py` breaks package imports silently (no error until runtime import). **Fix**: Populate with at minimum a docstring and `__version__`; optionally auto-export all agent classes after verifying class names with the regex sweep technique above.

- **Port conflicts**: When starting the MCP server (`run_workforce.py`), port 8000 may already be in use by another workforce instance. Check with `ss -tlnp | grep 8000` and use `MCP_PORT=8001` (or higher) to avoid conflicts.

## Examples

### Add composio to all agents

```bash
# Audit
for f in $(find agents/ -name "*.py" -not -name "__init__.py"); do
  grep -q '"composio"' "$f" || echo "MISSING: $f"
done

# Patch each missing file, then:
find agents/ -name "*.py" -not -name "__init__.py" -exec python3 -m py_compile {} \;
```

### Add a new skill to all agents

```bash
# Add self.load_skill("new_skill") to each __init__
# Then verify:
grep -rl 'load_skill("new_skill")' agents/ | wc -l
```

### Populate an empty `agents/__init__.py`

```python
# 1. Scan for class names
import re, os
for root, dirs, files in os.walk("agents"):
    for f in files:
        if f == "agent.py" or f.endswith("_agent.py"):
            path = os.path.join(root, f)
            classes = re.findall(r'class\s+(\w+)', open(path).read())
            print(f"{path}: {classes}")

# 2. Write imports using verified class names (NOT file names)
# 3. Verify with py_compile
```
