---
name: slack-bridge
description: "Slack bot for content pipeline triggers."
version: "1.0.0"
metadata:
  hermes:
    tags: [slack, bot, pipeline, slack-bridge, airtable, notion, composio]
    related-skills: [content-pipeline, content-researcher, content-writer, notion, airtable]
---

# Slack Bridge

Slack bot integration for the Content Generator Workforce.

## Commands

- `/pipeline <topic>` — Full pipeline: research → write → review → publish
- `/research <topic>` — Research only
- `/draft <topic>` — Research + write
- `/status` — Check workforce health

## Event-Driven

@mention or post "pipeline" in a channel to trigger the workforce.

## Integrations

- **Notion** — Brand guidelines, published content tracking
- **Airtable** — Content calendar, campaigns, published posts
- **Composio** — Cross-platform social media tools
- **Telegram** — Approval gateway for human review

## Setup

Add to `~/.hermes/.env`:
```
SLACK_BOT_TOKEN=xoxb-...
SLACK_APP_TOKEN=xapp-...
SLACK_SIGNING_SECRET=...
SLACK_ALLOWED_USERS=U0C1V5VMD9R
AIRTABLE_API_KEY=key_your_key_here
AIRTABLE_BASE_ID=appYourBaseId
NOTION_API_KEY=ntn_your_key_here
COMPOSIO_API_KEY=ak_your_key_here
```

Start: `.venv/bin/python slack_bridge/main.py`
