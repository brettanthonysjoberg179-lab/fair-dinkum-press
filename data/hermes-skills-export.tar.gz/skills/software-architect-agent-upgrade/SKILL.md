---
name: software-architect-agent-upgrade
description: Upgrade Software Architect MCP Agent.
---

# Software Architect + Engineer MCP Agent Upgrades

Location: `~/Bretts Agents/Agents/Software-Architect-Engineer-MCP/`

## Environment Setup

Copy your local `.env` into the agent directory:
```bash
cp ~/.env "/home/brettanthonysjoberg179/Bretts Agents/Agents/Software-Architect-Engineer-MCP/.env"
```

Add aliases (expanding from shell `${VAR}` to real values):
```
AIRTABLE_API_KEY=***
GITHUB_TOKEN=***
LLM_API_KEY=***
PAYPAL_ACCESS_TOKEN=***
PAYPAL_CLIENT_ID=***
PAYPAL_ENVIRONMENT=PRODUCTION
```

The agent venv is often broken or missing — recreate it:
```bash
cd "~/Bretts Agents/Agents/Software-Architect-Engineer-MCP"
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install pydantic httpx openai google-genai
```

## Known Issues & Fixes

### venv broken
When `python3 -m py_compile` passes but `from src.main import run_task` fails on `pydantic_core._pydantic_core`, the venv is corrupt — recreate it.

### Gemini model deprecation
- `gemini-2.0-flash` → 404 (removed)
- `gemini-2.0-flash-lite` → 404 (removed)
- `gemini-3.5-flash` → works (default)
- `gemini-3.5-flash-lite` → works, free tier
- `gemini-3.6-flash` → 503 (unavailable, high demand)

Default model in `src/llm.py` is `gemini-3.5-flash-lite`. Update via:
```patch
model_defaults = {"gemini": "gemini-3.5-flash-lite", ...}
```

### LLM key resolution
`get_default_client()` in `src/llm.py` must read provider-specific keys as fallback:
- `LLM_API_KEY` → generic
- `GEMINI_API_KEY` → Gemini
- `ANTHROPIC_API_KEY` → Anthropic
- `OPENAI_API_KEY` → OpenAI

Smart defaults per provider:
```python
base_url defaults: ollama=http://localhost:11434/v1, openai=https://api.openai.com/v1, anthropic=https://api.anthropic.com, gemini=https://generativelanguage.googleapis.com/v1beta
```

### Tool dispatch broken
LLM plans use `tool_name` but `tool_args` was not being extracted from the plan JSON. Fix in `src/main.py` `_parse_plan_from_llm`:
```python
tool_args=step_data.get("tool_args", {}),
```

Also add to `SYSTEM_PROMPT`:
```
IMPORTANT — Every plan step MUST include a `tool_args` object with the actual arguments the tool needs.
```

### Architecture

- `src/main.py` — state machine + CLI + API entry point (AgentRun, run_task, cli_loop)
- `src/llm.py` — LLM client (Ollama, OpenAI, Anthropic, Gemini; native + httpx fallback)
- `src/state.py` — pydantic state models (AgentStatus, Plan, PlanStep, AgentRun)
- `src/tools/__init__.py` — tool registry (88 tools: design/build/coding + 5 integration categories)
- `src/skills/design.py` — 4 design tools
- `src/skills/build.py` — 4 build tools
- `src/skills/coding.py` — 4 coding tools
- `src/integrations/` — 10 integration modules (github, huggingface, opencode, composio, honcho, openai, rags, airtable, obsidian, stripe)
- `src/integrations/github_client.py` — Full GitHub REST API (30 tools: repos, issues, PRs, CI/CD, search, files)
- `src/integrations/huggingface.py` — HuggingFace Hub API (models, datasets, spaces, papers, inference)
- `src/integrations/opencode.py` — OpenCode CLI wrapper (24 tools: agents, sessions, models, plugins, MCP, skills)
- `src/integrations/architect_mcp_server.py` — Unified MCP server (65 tools across 8 integrations)
- `src/integrations/hf_mcp_server.py` — HuggingFace MCP server (11 tools)
- `src/integrations/honcho.py` — Honcho API (users, thoughts, agents)
- `src/integrations/openai.py` — OpenAI API (chat, embeddings, images, audio, moderation)
- `src/integrations/composio/tooling.py` — Composio SDK (toolkits, tools, MCP servers)
- `src/integrations/airtable.py` — Airtable records
- `src/integrations/obsidian.py` — Obsidian vault (read, create, search)
- `src/integrations/stripe.py` — Stripe (customers, subscriptions, products)
- `src/rag.py` — RAG memory (SQLite vector store, 3 embedding backends: sentence-transformers → OpenAI → TF-IDF)

## User Keys

- HONCHO_API_KEY: hch-v3-1jdjsxeb6pao1qridap3pb2s8g4us0dxw46fhy869ri8u80fboabnwinvfowzzxz
- GEMINI_API_KEY: AQ.Ab8RN6JeC1AcwARJ6o8VlxHPeT1pQjfsQ7Y_jk63JG2DFe_sFA
- COMPOSIO_API_KEY: ak_3e-ZxzkzA3BN4ugKtmB6
- AIRTABLE_ACCESS_TOKEN: patvif9Tz4Kf0CILx
- GITHUB_PERSONAL_ACCESS_TOKEN: github...
- PAYPAL_ACCESS_TOKEN: EPVMy7hZn6rTRLV_... (Trend-Pro)
- PAYPAL_CLIENT_ID: BAAyHOLScOT8EGICPYFOkq9-... (Trend-Pro)