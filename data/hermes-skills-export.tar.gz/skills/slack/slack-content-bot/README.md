# Slack Content Bot

A Slack bot that triggers the content workforce pipeline via `/pipeline`.

## Files

- `slack_content_bot.py` — Main bot, Socket Mode listener + command router
- `commands.py` — Slash command parsing and validation
- `SKILL.md` — Skill definition (in skill directory)

## Setup

1. Create Slack app at api.slack.com/apps
2. Enable Socket Mode
3. Set env vars: `SLACK_BOT_TOKEN`, `SLACK_APP_TOKEN`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_HOME_CHANNEL`
4. Run: `python3 slack_content_bot.py`

## Commands

- `/pipeline <topic>` — Run full content pipeline
- `/pipeline status` — Check last run status
- `/pipeline cancel` — Cancel running pipeline
- `/pipeline retry` — Retry last rejected draft
