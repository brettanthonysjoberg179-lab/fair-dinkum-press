#!/usr/bin/env python3
"""Slack Content Bot — triggers content workforce pipeline via /pipeline command."""

import os
import sys
import json
import asyncio
from pathlib import Path

HERMES_HOME = Path(os.environ.get("HERMES_HOME", str(Path.home() / ".hermes")))
WORKSPACE = Path(os.environ.get("BH_AGENT_WORKSPACE", str(Path.home() / ".hermes" / "workspace")))

try:
    from slack_sdk.web.async_client import AsyncWebClient
    from slack_sdk.socket_mode import SocketModeClient
    from slack_sdk.socket_mode.request import SocketModeRequest
    from slack_sdk.socket_mode.response import SocketModeResponse
    SLACK_SDK_AVAILABLE = True
except ImportError:
    SLACK_SDK_AVAILABLE = False


class SlackContentBot:
    """Slack bot that wraps the content-pipeline coordinator."""

    def __init__(self):
        self.bot_token = os.environ.get("SLACK_BOT_TOKEN")
        self.app_token = os.environ.get("SLACK_APP_TOKEN")
        self.web_client = None
        self.socket_client = None

        if not SLACK_SDK_AVAILABLE:
            raise RuntimeError("slack-sdk not installed. Run: pip install slack-sdk")

        if not self.bot_token or not self.app_token:
            raise ValueError("Missing SLACK_BOT_TOKEN or SLACK_APP_TOKEN in environment.")

        self.web_client = AsyncWebClient(token=self.bot_token)
        self.socket_client = SocketModeClient(app_token=self.app_token, web_client=self.web_client)

    async def handle_command(self, command: str, channel_id: str, user_id: str) -> str:
        """Route slash commands to pipeline actions."""
        parts = command.strip().split()
        if not parts:
            return "Usage: `/pipeline <topic>` or `/pipeline status`"

        verb = parts[0].lower()

        if verb == "status":
            return "Pipeline status: idle (no recent runs)."
        elif verb == "cancel":
            return "No running pipeline to cancel."
        elif verb == "retry":
            return "No rejected draft to retry."
        else:
            topic = " ".join(parts)
            return await self._run_pipeline(topic, channel_id, user_id)

    async def _run_pipeline(self, topic: str, channel_id: str, user_id: str) -> str:
        """Run the full content pipeline for a topic."""
        await self._post_message(channel_id, f":mag: Researching *{topic}*...")

        try:
            # Phase 1: Research
            brief_path = WORKSPACE / "briefs" / f"{topic.replace(' ', '_')}_brief.md"
            brief_path.parent.mkdir(parents=True, exist_ok=True)
            brief_path.write_text(f"# Brief: {topic}\n\n[TODO: research output]")
            await self._post_message(channel_id, f":page_facing_up: Brief saved.")

            # Phase 2: Writing
            draft_path = WORKSPACE / "drafts" / f"{brief_path.stem}_draft.md"
            draft_path.parent.mkdir(parents=True, exist_ok=True)
            draft_path.write_text(f"# Draft from {brief_path.name}\n\n[TODO: writing output]")
            await self._post_message(channel_id, f":pencil: Draft saved.")

            # Phase 3: Telegram Approval (auto-approve placeholder)
            await self._post_message(channel_id, ":white_check_mark: Draft approved. Publishing...")

            # Phase 4: Publish
            await self._post_message(channel_id, f":rocket: Published: {draft_path}")
            return "Pipeline complete."

        except Exception as e:
            await self._post_message(channel_id, f":x: Pipeline failed: {str(e)}")
            return f"Pipeline error: {e}"

    async def _post_message(self, channel_id: str, text: str) -> None:
        """Post a message to a Slack channel."""
        if self.web_client:
            await self.web_client.chat_postMessage(channel=channel_id, text=text)

    async def run(self):
        """Start the Socket Mode listener."""
        async def process_request(request: SocketModeRequest):
            if request.type == "event_callback":
                event = request.payload.get("event", {})
                if event.get("type") == "app_mention":
                    channel = event["channel"]
                    user = event["user"]
                    text = event.get("text", "")
                    command = text.replace("<@USLACKBOT>", "").strip()
                    response = await self.handle_command(command, channel, user)
                    await self._post_message(channel, response)

            socket_resp = SocketModeResponse(envelope_id=request.envelope_id)
            await self.socket_client.send_socket_mode_response(socket_resp)

        print("Slack Content Bot listening via Socket Mode...")
        await self.socket_client.connect()
        while True:
            await asyncio.sleep(60)


def main():
    bot = SlackContentBot()
    asyncio.run(bot.run())


if __name__ == "__main__":
    main()
