#!/usr/bin/env python3
"""Slash command handlers for the Slack Content Bot."""

from pathlib import Path

HERMES_HOME = Path.home() / ".hermes"
WORKSPACE = HERME_HOME / "workspace"


def parse_pipeline_command(text: str) -> dict:
    """Parse /pipeline command arguments. Returns dict with action, topic, options."""
    text = text.strip()
    if text.startswith("/"):
        text = text[1:]

    parts = text.split()
    if not parts:
        return {"action": "help", "topic": "", "options": {}}

    command = parts[0].lower()
    if command in ("status", "cancel", "retry", "help"):
        return {"action": command, "topic": "", "options": {}}

    topic_parts = []
    options = {}
    i = 0
    while i < len(parts):
        if parts[i].startswith("--"):
            key = parts[i][2:]
            if i + 1 < len(parts) and not parts[i + 1].startswith("--"):
                options[key] = parts[i + 1]
                i += 2
            else:
                options[key] = True
                i += 1
        else:
            topic_parts.append(parts[i])
            i += 1

    return {"action": "pipeline", "topic": " ".join(topic_parts), "options": options}


def validate_topic(topic: str) -> tuple:
    """Validate a pipeline topic. Returns (is_valid, error_message)."""
    if not topic.strip():
        return False, "Topic cannot be empty. Usage: `/pipeline <topic>`"
    if len(topic) > 200:
        return False, "Topic too long (max 200 characters)."
    if any(c in topic for c in ["<", ">", "{", "}"]):
        return False, "Topic contains invalid characters."
    return True, ""


if __name__ == "__main__":
    test_cases = [
        "/pipeline latest AI developments",
        "/pipeline status",
        "/pipeline Q3 plan --platform linkedin",
    ]
    for tc in test_cases:
        result = parse_pipeline_command(tc)
        print(f"{tc} → {result}")
