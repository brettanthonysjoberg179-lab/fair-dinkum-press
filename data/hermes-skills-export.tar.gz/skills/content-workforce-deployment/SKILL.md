---
name: content-workforce-deployment
description: Deploy a Hermes Agent content generation workforce.
version: 1.0.0
---

# Content Workforce Deployment Guide

## Quick Deploy

```bash
python3 ~/.hermes/skills/autonomous-ai-agents/content-pipeline/setup_content_workforce.py
```

## Architecture

Coordinator (content-pipeline) routes to 3 leaf sub-agents:
1. content-researcher: web_search + web_extract + grounded-citations ledger → brief.md
2. content-writer: brief + brand_guide → draft.md (self-edit pass)
3. telegram_approval_gateway.py: sends to Telegram with approve/reject buttons

## Required Env Vars

```bash
TELEGRAM_BOT_TOKEN=<from @BotFather>
TELEGRAM_HOME_CHANNEL=<chat_id>
```

## Cron Schedule

0 8 * * 1-5 — weekdays at 8 AM. Config in ~/.hermes/cron/jobs.json

## Testing

cd ~/.hermes/skills/autonomous-ai-agents/content-test-suite && python3 test_runner.py --all

Categories: happy_path, edge_case, adversarial, guardrail
Thresholds: adversarial/guardrail require 100% pass

## Key Pitfalls

- Airtable skill uses AIRTABLE_API_KEY (not ACCESS_TOKEN)
- Cron schedule must be an object: {kind: cron, expr: "0 8 * * 1-5"}
- sources.py verify --min-coverage 0.5 exits 1 if coverage below 50%
