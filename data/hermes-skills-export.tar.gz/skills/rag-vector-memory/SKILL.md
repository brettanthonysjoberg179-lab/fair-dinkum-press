---
name: rag-vector-memory
description: "Build RAG systems with persistent vector memory backends."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [rag, vector-database, memory, embeddings, retrieval, architecture]
    category: research
    related_skills: [architecture-diagram, llm-wiki, grounded-citations]
---

# RAG Vector Memory

Build Retrieval-Augmented Generation systems with persistent vector memory backends.

This skill covers the full lifecycle: architecture design, vector database setup,
embedding generation, retrieval pipeline, memory consolidation, and feedback loops.

## When This Skill Activates

Use this skill when the user:
- Asks to create a RAG system, vector memory database, or memory-augmented LLM
- Asks to design the architecture for memory-enhanced retrieval
- Needs to set up a vector store for persistent knowledge
- Wants to implement a feedback loop where model outputs update memory
- References "RAGS", "memory vector", or "persistent retrieval-augmented generation"

## Architecture: The RAGS Pattern

```
User Query
  → Query Encoder → Embedding Model
    → Vector Memory Store (retrieval)
      → Context Builder (augment prompt)
        → LLM Generator
          → Response
            → Feedback Loop (write back to memory)
```

The Vector Memory Store is the central differentiator from vanilla RAG:
memories persist across sessions, consolidate over time, and evolve via feedback.

## Component Types (for architecture-diagram skill)

When diagramming RAGS systems, use these component classifications:

| Component | Diagram Color | CSS Class |
|---|---|---|
| Vector Memory Store | violet (#a78bfa) | Database fill + violet stroke |
| Memory Operations (Store/Retrieve/Consolidate) | rose (#fb7185) | Security fill + rose stroke |
| Embedding Model | amber (#fbbf24) | Cloud fill + amber stroke |
| Feedback Loop | rose dashed | Rose dashed arrow |

The architecture-diagram skill handles the visual rendering; this skill supplies
the RAGS-specific component definitions.

## Vector Database Implementation

### Pure-Python Option (sqlite3 + numpy)

For lightweight or offline deployments, use `sqlite3` for storage + `numpy` for
vector math. The `RAGSMemoryDB` class provides:

- `store(content, memory_type, metadata, confidence)` — insert a memory vector
- `retrieve(query, top_k, memory_types)` — cosine similarity search
- `consolidate(threshold)` — deduplicate similar memories
- `forget(id)` / `hard_forget(id)` — soft/hard delete
- `add_feedback(memory_id, type, strength)` — feedback loop entry
- `stats()` — database statistics
- `list_active()` — all active memories sorted by confidence

Schema (5 tables):
- `memory_vectors` — content, embedding (JSON), type, confidence, metadata
- `vector_index` — bucket-hash approximate indexing for fast retrieval
- `query_log` — query history and results
- `memory_feedback` — feedback loop entries
- `system_schema` — version/config metadata

### Production Option

For production deployments, replace the pure-Python embedding generator with:
- `sentence-transformers` (local, e.g., all-MiniLM-L6-v2)
- `openai` `text-embedding-3-small` (cloud API)
- `cohere` embed API
- `qdrant_client`, `chromadb`, or `pinecone` (managed vector DBs)

The schema and API remain the same — only `_generate_embedding()` changes.

## Memory Types

| Type | Purpose | Typical confidence |
|---|---|---|
| `semantic` | General knowledge, concepts | 0.5–0.9 |
| `fact` | Specific factual assertions | 0.6–0.8 |
| `working` | Short-term context, session state | 0.3–0.6 |

Consolidation thresholds vary by type: semantic memories survive longer (higher
threshold), working memories expire sooner.

## Feedback Loop

The RAGS feedback loop closes the system:
1. LLM generates a response from retrieved context
2. User feedback (explicit or implicit) is recorded via `add_feedback()`
3. The consolidation process merges high-confidence feedback into semantic memory
4. Low-confidence or contradictory feedback is flagged for review

## Procedures

### Initialize a RAGS Memory Database

1. Install dependencies: `pip install numpy` (for vector operations)
2. Create the database module at `<project>/rags_memory_db.py`
3. Instantiate: `db = RAGSMemoryDB("<path>/rags_memory.db", embedding_dim=128)`
4. Seed with domain-specific memories using `db.store()`

### Query the Memory

1. Call `db.retrieve(query, top_k=5)` for similarity search
2. Filter by `memory_types=['semantic', 'fact']` to exclude working memory
3. Rank results by `similarity` score (cosine similarity, unit-normalized)
4. Log the query: `db.log_query(query_text, embedding, results, response)`

### Consolidate and Maintain

1. Run `db.consolidate(threshold=0.9)` periodically to deduplicate
2. Review `db.stats()` for memory type distribution
3. Use `db.add_feedback()` to record model-user interaction outcomes
4. Archive stale memories via `db.forget()`

## Pitfalls

- **Hash-based embeddings are pseudo-embeddings.** The included `_generate_embedding()`
  uses deterministic SHA-256 hashing — useful for demo but not for production.
  Real semantic similarity requires a trained embedding model.
- **Bucket index collision.** The bucket-hash approximate index may miss candidates
  from other buckets. If retrieval quality is poor, increase `bucket_size` or do
  a full scan (the `retrieve()` method falls back automatically).
- **SQLite JSON embedding storage.** Embeddings are stored as JSON strings in
  SQLite TEXT columns. This works but is slower than binary vectors in
  dedicated vector DBs for large-scale deployments.
- **Never forget the consolidation step.** Without periodic consolidation,
  the memory store grows unbounded and retrieval degrades from noise.
- **Feedback without consolidation is just logging.** The feedback loop only
  improves memory if consolidation acts on it.

## Verification

1. Store 3+ memories of different types
2. Run `db.retrieve()` on a query related to one of them
3. Confirm the correct memory ranks in top-K with reasonable similarity (>0.1)
4. Run `db.consolidate()` and verify `db.stats()` shows correct counts
5. Call `db.add_feedback()` and confirm `memory_feedback` table has entries
