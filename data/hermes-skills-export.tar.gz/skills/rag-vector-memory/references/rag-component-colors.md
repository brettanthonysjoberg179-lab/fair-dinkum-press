# RAG Component Color Definitions for Architecture Diagrams

When diagramming RAGS (Retrieval-Augmented Generation with Memory) systems
using the architecture-diagram skill, use these component classifications.

## Vector Memory Store

The central component that distinguishes RAGS from vanilla RAG.

```svg
<!-- Violet-tinted database box for vector memory -->
<rect x="340" y="210" width="420" height="380" rx="12"
      fill="rgba(76, 29, 149, 0.08)" stroke="#a78bfa" stroke-width="2"/>
<text x="352" y="232" fill="#a78bfa" font-size="11" font-weight="700">VECTOR MEMORY STORE</text>
```

- **Fill:** `rgba(76, 29, 149, 0.08)` (light violet tint)
- **Stroke:** `#a78bfa` (violet-400)
- **Label color:** `#a78bfa` for headers, `#c4b5fd` for sublabels
- **Border width:** 2px (emphasis — it's the centerpiece)

## Memory Operations (Store/Retrieve/Consolidate)

The three core operations inside the memory store.

```svg
<!-- Rose-tinted boxes for memory operations -->
<rect x="360" y="440" width="120" height="50" rx="8"
      fill="rgba(136, 19, 55, 0.4)" stroke="#fb7185" stroke-width="1.5"/>
```

- **Fill:** `rgba(136, 19, 55, 0.4)` (rose-400 standard)
- **Stroke:** `#fb7185` (rose-400)
- **Label color:** `#fb7185` for operation labels

## Embedding Model

The model that converts text to vectors.

```svg
<rect x="480" y="55" width="140" height="50" rx="8"
      fill="rgba(120, 53, 15, 0.3)" stroke="#fbbf24" stroke-width="1.5"/>
```

- **Fill:** `rgba(120, 53, 15, 0.3)` (amber standard)
- **Stroke:** `#fbbf24` (amber-400)

## Feedback Loop

The dashed arrow from LLM output back to memory store.

```svg
<line x1="910" y1="335" x2="910" y2="358"
      stroke="#fb7185" stroke-width="1.5" marker-end="url(#arrowhead-rose)"
      stroke-dasharray="5,5"/>
```

- **Style:** Dashed line (`stroke-dasharray="5,5"`)
- **Color:** Rose (`#fb7185`)
- **Arrowhead:** Rose marker

## Memory Type Color Coding

| Type | Legend Dot | Usage |
|---|---|---|
| `semantic` | violet dot | Long-term knowledge, concepts |
| `fact` | amber dot | Specific assertions, user preferences |
| `working` | cyan dot | Short-term context, session state |
