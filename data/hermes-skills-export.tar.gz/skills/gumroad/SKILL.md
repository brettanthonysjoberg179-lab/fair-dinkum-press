---
name: gumroad
description: "Gumroad CLI: products, sales, files, profile pages."
version: 1.0.0
author: Brett Sjoberg, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [gumroad, gumroad-cli, digital-products, sales, licenses, landing-pages]
    category: digital-products
    related_skills: [github, rags-knowledge-base]
---

# Gumroad

Interact with Gumroad via the `gumroad` CLI (wraps every REST endpoint). Installs via `brew install antiwork/cli/gumroad` or `curl -fsSL https://gumroad.com/install-cli.sh | bash`. Currently installed at `~/.local/bin/gumroad` (v2026.09.09).

## Auth

```sh
gumroad auth login        # device flow
gumroad auth status       # check token
export GUMROAD_ACCESS_TOKEN=...   # CI / agents
```

## Routing

| Task | CLI command |
|---|---|
| List products | `gumroad products list` |
| Inspect product | `gumroad products show <id>` |
| Create product | `gumroad products create --type digital --name NAME --price PRICE` |
| Update product | `gumroad products update <id> --name NEW_NAME` |
| Delete product | `gumroad products delete <id>` |
| Publish / unpublish | `gumroad products publish <id>` / `gumroad products unpublish <id>` |
| Upload file + attach | `gumroad products create --file ./file.pdf` |
| List sales | `gumroad sales list --all` |
| View sale | `gumroad sales view <id>` |
| Refund sale | `gumroad sales refund <id> --amount 5.00` |
| List subscribers | `gumroad subscribers list --product <id>` |
| Verify license | `echo KEY | gumroad licenses verify --product <id>` |
| Payouts | `gumroad payouts list` |
| Webhooks | `gumroad webhooks create --resource sale --url https://...` |
| Custom profile page | `gumroad user page preview <file>` then `gumroad user page publish` |

## Cover Images

Add cover images to products:

```sh
gumroad products update <id> --cover-image ./cover.png
```

Cover images show on the Gumroad product listing page and in search/social previews. Use 1200×630px (16:9) for best results. Accepted formats: JPG, PNG, GIF (≤10MB).

### Batch cover generation

Generate covers programmatically with Python/Pillow:

```python
from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 630
img = Image.new("RGB", (W, H))
draw = ImageDraw.Draw(img)
# ... draw gradient, title, price badge, category pill ...
img.save("cover.png", "PNG")
```

Use a category-specific color scheme so each product is visually distinct but the store looks cohesive. Include: product title (large, bold), price badge, category pill, subtle decorative shapes (circles, gradient overlays).

When uploading covers in a batch, quote filenames — shell characters like `-`, `&`, and spaces in filenames will break command chaining. Build a mapping of product IDs to filenames, then iterate:

```sh
# BAD: filename with - breaks shell parsing
gumroad products update ID --cover-image Name-with-dash.png && ...  # fails

# GOOD: quote every filename
gumroad products update ID --cover-image "Name-with-dash.png" 2>&1
```

## Digital Product Creation Workflow

When creating digital products on Gumroad, follow this order:

1. **Create the listing** with `gumroad products create` (this auto-publishes by default).
2. **Verify `files` count is non-zero** immediately after creation — `gumroad products create` publishes even when no files are attached. A published listing with `files[]` empty will accept payments but deliver nothing.
3. **Attach content before attempting sales** — either via `gumroad products create --file ./your.pdf` at creation time, or `gumroad products update <id> --file ./your.pdf` for existing products.
4. **Confirm full deliverable** — check that product `files` array is non-empty AND that the file(s) match the description.
5. **Beware `gumroad products update <id> --file ./file.pdf` ADDS — it does NOT replace.** Running it N times accumulates N duplicate files. Always check current file count first (`gumroad products content get <id>` or API `files[]`) before re-running.

## Pitfalls

- Always attach files before declaring a product "ready to sell" — Gumroad will happily publish a product with zero files attached. The buyer receives nothing.
- Default currency is AUD on create — always pass `--currency usd` explicitly when the store is USD-denominated.
- API daily product limit: 10 products per day. If you get "Sorry, you can only create 10 products per day," wait until the next UTC day to continue. Set a cron reminder rather than retrying.
- The install script at `https://gumroad.com/install-cli.sh` pipes to bash — only run from trusted network. On this Linux box, Homebrew is absent; the install script is the correct path.
- `gumroad pages preview` is `gumroad user page preview` (not `gumroad pages preview`); `gumroad pages push` is `gumroad user page publish`.
- Publishing requires a payment method first — `gumroad products publish <id>` fails with 'You must connect at least one payment method' if no card/bank is configured at https://gumroad.com/settings/payouts. Always set up payouts before attempting to publish products.
- When batch-creating multiple products, stagger calls — parallel execution of 5+ `gumroad products create` calls can trigger rate limits (30 PUTs/min). Stagger with small delays or use sequential calls when possible.
- Gumroad `payouts list` returns `[ ]` with no completed payouts — this does NOT mean no payment method is configured. Only a successful `publish` confirms payment setup.
- `gumroad products update <id> --file ./file.pdf` ADDS files to the product's `files[]` array — it does NOT replace existing files. Running it N times on the same product accumulates N duplicate files. Check `files[]` count via the API before re-running, or use `gumroad products content get <id>` to inspect current state.
- **Gumroad generates license keys automatically at purchase time** — there is no API or CLI command to pre-generate or create arbitrary license keys. `gumroad licenses enable`, `disable`, `rotate`, and `verify` all operate ONLY on keys that already exist from completed purchases. A license key is born when a buyer completes checkout. If you need to deliver a license key to a buyer outside of Gumroad's purchase flow, you must build your own license/key system.
- Product content can flag a file as license-gated via `{"type": "fileEmbed", "attrs": {"licenseKey": true}}` in the rich content description. This tells Gumroad to generate and deliver a unique key to the buyer after purchase.
- **Cover images**: `gumroad products update <id> --cover-image ./cover.png` — JPG/PNG/GIF ≤10MB, 1200×630px recommended for 16:9 product cards and social previews.
- Gumroad strips `<meta>`, `<title>`, `<viewport>`, and `<link rel="preconnect">` from custom HTML on preview — do not rely on them for SEO or responsive behavior; CSS `@media` and inline `<style>` are preserved. Load Google Fonts via a single `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=...">` — preconnect links are stripped and the font load fails silently.
- Stripe verification may reject non-standard government IDs (e.g., SA Proof of Age card). If Stripe verification fails, Gumroad payouts can be switched to PayPal instead — but this is done exclusively via the web UI at gumroad.com/settings/payouts; there is no CLI command to configure payout methods.
- No version history for landing pages — keep source under your own version control.
- The profile page is a sandboxed iframe; `fetch`/`XHR`/WebSocket are blocked. Only Gumroad CDN, Google Fonts, Bunny Fonts, Tailwind/jsDelivr/unpkg CDNs load externally.
- SVG is rejected in the media library (script risk). Images must be ≤10MB, JPG/PNG/GIF.
- `files` on PUT `/v2/products/:id` is a full replacement — omitting a file deletes it. Preserve existing file IDs when updating.

## Verification

- Read endpoints return `"success": true`.
- Write operations echo the mutated resource with updated fields.
- Sales: check `"success": true` and `id` present.
- Licenses: verify returns `"uses"` count and purchase details.
- Profile page: `gumroad user page url` confirms live URL after publish.

## Pitfalls

- Gumroad strips `<meta>`, `<title>`, `<viewport>`, and `<link rel="preconnect">` from custom HTML on preview — do not rely on them for SEO or responsive behavior; CSS `@media` and inline `<style>` are preserved. Load Google Fonts via a single `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=...">` — preconnect links are stripped and the font load fails silently.
- Stripe verification may reject non-standard government IDs (e.g., SA Proof of Age card). If Stripe verification fails, Gumroad payouts can be switched to PayPal instead — but this is done exclusively via the web UI at gumroad.com/settings/payouts; there is no CLI command to configure payout methods.
- No version history for landing pages — keep source under your own version control.
- The profile page is a sandboxed iframe; `fetch`/`XHR`/WebSocket are blocked. Only Gumroad CDN, Google Fonts, Bunny Fonts, Tailwind/jsDelivr/unpkg CDNs load externally.
- SVG is rejected in the media library (script risk). Images must be ≤10MB, JPG/PNG/GIF.
- `files` on PUT `/v2/products/:id` is a full replacement — omitting a file deletes it. Preserve existing file IDs when updating.
- The install script at `https://gumroad.com/install-cli.sh` pipes to bash — only run from trusted network. On this Linux box, Homebrew is absent; the install script is the correct path.
- `gumroad pages preview` is `gumroad user page preview` (not `gumroad pages preview`); `gumroad pages push` is `gumroad user page publish`.
- Publishing requires a payment method first — `gumroad products publish <id>` fails with 'You must connect at least one payment method' if no card/bank is configured at https://gumroad.com/settings/payouts. Always set up payouts before attempting to publish products.
