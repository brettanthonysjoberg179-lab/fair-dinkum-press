# Linux Font Paths for Pillow Cover Generation

When generating covers with Python/Pillow on this Linux box:

**Working font paths:**
- Bold: `/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf`
- Regular: `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf`

**Pillow font loading pattern:**
```python
def get_font(size, bold=True):
    paths = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
    ]
    for p in paths:
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()
```

**Available libraries:**
- Pillow 12.3.0 (`from PIL import Image, ImageDraw, ImageFont`)

**Recommended cover dimensions:** 1200×630px (16:9) — matches Gumroad product card and social preview aspect ratios.

**Gradient drawing pattern:**
```python
def draw_gradient(img, c1, c2):
    draw = ImageDraw.Draw(img)
    r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
    r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
    for i in range(H):
        t = i / H
        r, g, b = int(r1+(r2-r1)*t), int(g1+(g2-g1)*t), int(b1+(b2-b1)*t)
        draw.line([(0, i), (W, i)], fill=(r, g, b))
```
