# Gumroad API Reference

Quick lookup for common endpoints and patterns.

## Products

```bash
gumroad products list
gumroad products show <id>
gumroad products create --type digital --name "My Product" --price 9.99
gumroad products update <id> --name "Updated"
gumroad products delete <id>
gumroad products publish <id>
gumroad products unpublish <id>
```

## Sales

```bash
gumroad sales list --all --json
gumroad sales list --all --json --jq '.sales[] | {email, formatted_total_price}'
gumroad sales view <id>
gumroad sales refund <id> --amount 5.00
gumroad sales ship <id> --tracking-url https://...
gumroad sales resend-receipt <id>
```

## Files

```bash
gumroad files upload ./course.pdf
```

## Emails

```bash
gumroad emails list --type draft
gumroad emails create --subject "Hello" --body ./email.html --audience all
gumroad emails send <id>
gumroad emails schedule <id> --to-be-published-at "2026-07-01 14:00"
```

## Webhooks / Subscriptions

```bash
gumroad webhooks create --resource sale --url https://...
gumroad webhooks list --resource sale
gumroad webhooks delete <id>
```

## License Key Content Pattern

To flag a product as license-key-delivered, include a `fileEmbed` with `"licenseKey": true` in the product's rich content description. Gumroad then auto-generates a unique key per purchase.

```json
{
  "type": "fileEmbed",
  "attrs": {
    "id": "...",
    "uid": "...",
    "collapsed": false,
    "licenseKey": true
  }
}
```

This is auto-generated on sale — no manual key management needed via CLI.

## Payouts

```bash
gumroad payouts list
gumroad payouts view <id> --include-transactions
gumroad payouts upcoming
```

## Public profile

```bash
curl https://<username>.gumroad.com/.json
```

## Categories

```bash
curl https://api.gumroad.com/v2/categories -d "access_token=$TOKEN"
```

## User

```bash
gumroad user
gumroad user page preview ./landing.html
gumroad user page publish ./landing.html
```

## Refund Policy

```bash
gumroad refund-policy view
gumroad refund-policy set --period 30 --fine-print "Reviewed within 2 business days."
```

## Variants

```bash
gumroad variant-categories create --product <id> --title colors
gumroad variants create --product <id> --category <cat-id> --name red --price-difference 2.50
gumroad variants list --product <id> --category <cat-id>
```

## Offer Codes

```bash
gumroad offer-codes create --product <id> --name SUMMER20 --amount 2.00 --offer-type percent
gumroad offer-codes list --product <id>
```

## Custom Fields

```bash
gumroad custom-fields create --product <id> --name "phone number" --required
gumroad custom-fields list --product <id>
```
