---
name: project-scaffold
description: "Scaffold new projects with structure and configs."
version: 1.0.0
author: Brett Anthony Sjoberg, Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [project, scaffold, setup, structure]
    category: software-development
    related_skills: [github, hermes-agent-skill-authoring]
---

# Project Scaffold

Create a new project directory with standard subfolder structure, configuration files, and a README.

## When to Use

- User asks to create a new project, workspace, or folder structure
- Setting up a new agent, tool, or service directory
- Initializing a repository with standard conventions

## Procedure

### 1. Create the folder structure

Use `terminal` with `mkdir -p` and brace expansion:
```bash
mkdir -p "<Project Name>"/{Sub1,Sub2,Sub3}
```

### 2. Add a top-level README.md

Use `write_file` for the project README. Include: project description, subfolder map, getting started, and integration references.

### 3. Add .gitignore

Use `write_file` for `.gitignore`. Cover: `__pycache__`, `*.pyc`, `venv/`, `.env`, `.idea/`, `.vscode/`, `.DS_Store`, `*.db`, `*.sqlite`, build artifacts.

### 4. Add .env.example

Use `write_file` for `.env.example`. List all env vars: LLM/provider settings, API keys for each integration, config placeholders. Mark required vs optional.

### 5. Create subfolder READMEs

Each subfolder gets a `README.md` describing purpose, structure conventions, and adding new files.

### 6. Create __init__.py for Python packages

Use `write_file` for `__init__.py`. Use triple-quoted docstrings: `"""Package description."""`. NOT bare text or markdown headers — Python files MUST compile.

### 7. Initialize git and commit

```bash
cd "<Project Name>"
git init
git add -A
git commit -m "feat: initial project scaffold"
```

### 8. Set up GitHub remote

Check `gh auth status` first. Then:
```bash
gh repo create <repo-name> --private --description "Project description"
```
If `gh repo create` fails with 403, the PAT lacks the `repo` scope. Regenerate at https://github.com/settings/tokens with `repo`, `workflow`, `read:org` scopes.

## Key Pitfalls

- **Python files need triple-quoted docstrings.** `.py` files written via `write_file` must be valid Python. Use `"""Module description."""` at the top — `py_compile` rejects bare text.
- **`gh repo create` flag conflicts.** `--source` cannot combine with `--license`, `--clone`, or `--gitignore`. Create repo without flags, then `git remote add` and push.
- **PAT scope limitations.** Token without `repo` scope can read but not push or create repos. Verify token scope before repo operations.
- **Shell brace expansion catches existing dirs.** `mkdir -p` with brace expansion silently includes pre-existing subdirectories. Use `find` to verify intended folders.
- **Inline token sharing preferred.** Store tokens in `.env` files, not vault. User prefers `HONCHO_API_KEY=...` inline env vars.
- **AIRTABLE_API_KEY not AIRTABLE_ACCESS_TOKEN.** Airtable integrations expect `AIRTABLE_API_KEY` env var.
- **Don't use heredocs for Python files.** They produce files without proper module docstrings. Use `write_file` with valid Python syntax.

## Verification

1. Each Python file passes `py_compile`
2. `find <project> -type f | wc -l` matches expected file count
3. `git status` shows clean working tree after commit
4. `gh auth status` succeeds before GitHub operations
5. All subfolder READMEs exist and are non-empty
6. `.gitignore` covers expected artifact patterns
7. `.env.example` lists every integration's credential variable

## User Preferences

- Inline token sharing over vault setup
- Concise, structured summaries
- Python 3.13+ runtime
- Venvs per sub-project
- Composite skill patterns for multi-agent work
