---
name: rags-memory-vector-db
description: "Use when querying the RAGS memory vector database."
tags: [rag, memory, vector, sqlite]
---

# RAGS Memory Vector Database

Persistent memory vector database for Retrieval-Augmented Generation with Memory.

## Location
- Database: `/home/brettanthonysjoberg179/rags_memory_db/rags_memory.db`
- Module: `/home/brettanthonysjoberg179/rags_memory_db/rags_memory_db.py`

## Quick Usage
```python
from rags_memory_db import RAGSMemoryDB
db = RAGSMemoryDB('/home/brettanthonysjoberg179/rags_memory_db/rags_memory.db')
mem_id, uuid = db.store(content, memory_type='semantic', confidence=0.7)
results = db.retrieve(query, top_k=5)
db.close()
```

## Schema
- memory_vectors: id, uuid, content, embedding (JSON), embedding_dim, metadata (JSON), memory_type, confidence, is_active
- vector_index: memory_id, bucket_id (approximate nearest neighbor)
- query_log: query_text, query_embedding, top_k_results, response
- memory_feedback: memory_id, feedback_type, strength
- system_schema: version, embedding_dim, index_method, created

## Memory Types
- semantic: Knowledge/concept memories
- fact: Factual/user preference memories
- working: Short-term context/working memories

## Notes
- 128-dimensional embeddings, 16 hash buckets
- For production, replace _generate_embedding() with sentence-transformers or OpenAI
- Consolidation deduplicates memories above similarity threshold

## Related Skills
- mcp-server-agents: MCP knowledge modules stored in this database
