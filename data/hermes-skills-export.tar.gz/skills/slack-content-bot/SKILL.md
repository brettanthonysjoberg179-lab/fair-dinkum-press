---
name: slack-content-bot
description: "Slack bot wrapping content pipeline as /pipeline."
version: "1.0.0"
metadata:
  hermes:
    tags: [slack, bot, pipeline, content, automation]
    related-skills: [content-pipeline, content-researcher, content-writer, telegram-approval-gateway, slack-block-kit]
---

# Slack Content Bot

A Slack bot that wraps the content-pipeline coordinator as a `/pipeline` command.

## Architecture

```
Slack user → /pipeline <topic>
    ↓
Slack app (Socket Mode)
    ↓
Content Pipeline Coordinator (content-pipeline skill)
    ↓
  Research → Write → Telegram Approval → Publish
```

## Setup

### 1. Slack App Registration
- Create app at api.slack.com/apps
- Enable Socket Mode (WebSocket-based, no public URL needed)
- Add Bot Token Scopes: `app_mentions:read`, `commands`, `chat:write`, `links:read`
- Subscribe to message.im and app_mention events
- Install app to workspace, copy SLACK_BOT_TOKEN and SLACK_APP_TOKEN

### 2. Environment variables (~/.hermes/.env)
```
SLACK_BOT_TOKEN=xoxb-...
SLACK_APP_TOKEN=xapp-...
SLACK_SIGNING_SECRET=...
TELEGRAM_BOT_TOKEN=...
TELEGRAM_HOME_CHANNEL=...
AIRTABLE_API_KEY=patvif9Tz4Kf0CILx
```

### 3. Install the bot script
```bash
mkdir -p ~/.hermes/skills/slack/slack-content-bot
```
Copy slack_content_bot.py and commands.py into that directory.

## Usage

```
/pipeline latest AI developments
/pipeline Q3 content plan --platform linkedin
/pipeline status
```

## Commands

| Command | Action |
|---------|--------|
| `/pipeline <topic>` | Run full pipeline |
| `/pipeline status` | Check last run status |
| `/pipeline cancel` | Cancel running pipeline |
| `/pipeline retry` | Retry last rejected draft |

## Workflow

1. User types `/pipeline <topic>` in any channel
2. Bot receives command, delegates to content-pipeline coordinator
3. Pipeline runs: research → write → Telegram approval
4. Bot posts status update to the channel
5. If approved → publishes, posts result link
6. If rejected → posts feedback, offers `/pipeline retry`